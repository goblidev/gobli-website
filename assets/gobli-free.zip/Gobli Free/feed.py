"""
Launch detection for the auto mode.

One WebSocket subscription: logsSubscribe filtered on pump.fun's
mint-authority PDA, which appears in coin creations and nothing else. It is a
standard Solana method, so it works on Helius' free plan.

The feed only runs while an auto rule is armed. Helius meters streaming
traffic by the megabyte, and a feed nobody is listening to would spend the
plan's credits for nothing. start() and stop() are cheap and idempotent; the
auto engine calls them as rules are armed, paused and expire.

A subscription the server rejects is marked unavailable rather than left
looking connected, because a silently dead feed is indistinguishable from a
quiet market.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import time
from collections import OrderedDict
from typing import AsyncIterator, Optional

import websockets

import config
from logger import get_logger
from pumpfun import Launch, parse_logs_notification

_log = get_logger(__name__)

_SEEN_CAPACITY = 5_000
_REFUSAL_RETRY_SECONDS = 300.0


class LaunchFeed:
    def __init__(self, ws_url: str, commitment: str = config.FEED_COMMITMENT) -> None:
        self._url = ws_url
        self._commitment = commitment
        self._queue: asyncio.Queue[Launch] = asyncio.Queue(maxsize=500)
        self._task: Optional[asyncio.Task] = None
        self._seen: OrderedDict[str, None] = OrderedDict()

        self.connected = False
        self.unavailable_reason: Optional[str] = None
        self.messages_received = 0
        self.launches_seen = 0
        self.dropped = 0
        self.started_at: Optional[float] = None
        self._refused_at: Optional[float] = None

    @property
    def running(self) -> bool:
        return self._task is not None and not self._task.done()

    def start(self) -> None:
        if self.running:
            return
        # A refused subscription is retried after a pause, not on every call:
        # the refusal (wrong plan, bad endpoint) won't fix itself in seconds.
        if self._refused_at is not None and time.monotonic() - self._refused_at < _REFUSAL_RETRY_SECONDS:
            return
        self._refused_at = None
        self.unavailable_reason = None
        self.started_at = time.time()
        self._task = asyncio.create_task(self._run(), name="launch-feed")
        _log.info("Launch feed starting")

    async def stop(self) -> None:
        task, self._task = self._task, None
        self.connected = False
        if task is None:
            return
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await task
        # Launches queued before the stop are stale by the time anything
        # re-arms - drop them rather than act on them later.
        while not self._queue.empty():
            self._queue.get_nowait()
        _log.info("Launch feed stopped")

    async def events(self) -> AsyncIterator[Launch]:
        while True:
            yield await self._queue.get()

    def _is_new(self, signature: str) -> bool:
        if signature in self._seen:
            return False
        self._seen[signature] = None
        while len(self._seen) > _SEEN_CAPACITY:
            self._seen.popitem(last=False)
        return True

    async def _run(self) -> None:
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "logsSubscribe",
            "params": [
                {"mentions": [config.PUMP_MINT_AUTHORITY]},
                {"commitment": self._commitment},
            ],
        }
        delay = config.FEED_RECONNECT_BASE_DELAY_SECONDS
        while True:
            try:
                async with websockets.connect(
                    self._url, ping_interval=20, ping_timeout=20, max_size=8 * 1024 * 1024
                ) as ws:
                    await ws.send(json.dumps(payload))
                    ack_raw = await asyncio.wait_for(ws.recv(), timeout=15)
                    try:
                        ack = json.loads(ack_raw)
                    except json.JSONDecodeError:
                        ack = {}
                    if isinstance(ack, dict) and "error" in ack:
                        message = (ack.get("error") or {}).get("message") or str(ack["error"])
                        self.unavailable_reason = message
                        self.connected = False
                        self._refused_at = time.monotonic()
                        _log.error("Launch feed subscription refused: %s", message)
                        return

                    self.connected = True
                    delay = config.FEED_RECONNECT_BASE_DELAY_SECONDS
                    _log.info("Launch feed subscribed (%s)", self._commitment)

                    async for message in ws:
                        received_at = time.monotonic()
                        self.messages_received += 1
                        try:
                            envelope = json.loads(message)
                        except json.JSONDecodeError:
                            continue
                        launch = parse_logs_notification(envelope, received_at)
                        if launch is None or not self._is_new(launch.signature):
                            continue
                        self.launches_seen += 1
                        try:
                            self._queue.put_nowait(launch)
                        except asyncio.QueueFull:
                            self.dropped += 1
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.connected = False
                _log.warning("Launch feed disconnected (%r) - reconnecting in %.1fs", exc, delay)
                await asyncio.sleep(delay)
                delay = min(delay * 2, config.FEED_RECONNECT_MAX_DELAY_SECONDS)
