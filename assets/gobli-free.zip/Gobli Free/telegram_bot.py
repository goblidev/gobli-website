"""
Telegram interface.

/start opens the menu, where you choose between the two snipers:

  🎯 Manual - paste a token's mint address into the chat and it is bought.
  🤖 Auto   - set one rule (a creator wallet or a ticker) and pump.fun
              launches are watched and bought for you.

One mode is active at a time. Positions from either mode stay visible and
sellable in both.

Multi-step inputs (building a rule, typing a take-profit level) are tracked
as one pending step in the chat's user_data, and every text message checks
for a pending step before anything else - so a wallet address typed into the
rule builder is never mistaken for a mint to buy.

Security: only the chat id in TELEGRAM_CHAT_ID gets a response. Every other
chat is ignored silently, so probing the bot reveals nothing about whether
it is running.
"""

from __future__ import annotations

import asyncio
import contextlib
import html
import math
import re
import time
from typing import Optional

from solders.pubkey import Pubkey
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode
from telegram.error import BadRequest, InvalidToken
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

import config
import rules
from logger import get_logger
from positions import SOURCE_AUTO, SOURCE_MANUAL, Position
from pumpfun import is_mixed_script, normalize_ticker
from state import MODE_AUTO, MODE_MANUAL

_log = get_logger(__name__)

MINT_RE = re.compile(r"^[1-9A-HJ-NP-Za-km-z]{32,44}$")
SKIP_WORDS = {"skip", "none", "no", "-", "default"}
# A pump.fun curve graduates well before this much SOL is in it, so a higher
# threshold could never be met.
MAX_MIN_SOL_IN_CURVE = 80.0


# ----------------------------------------------------------------------------
# Formatting
# ----------------------------------------------------------------------------
def _esc(text) -> str:
    return html.escape(str(text or ""), quote=False)


def _fmt_usd(value: Optional[float]) -> str:
    return f"${value:,.0f}" if value is not None else "n/a"


def _fmt_price(value: Optional[float]) -> str:
    if value is None or value <= 0:
        return "n/a"
    if value >= 1:
        return f"${value:,.4f}"
    decimals = min(-math.floor(math.log10(value)) + 3, 14)
    return f"${value:.{decimals}f}"


def _fmt_amount(value: float) -> str:
    return f"{value:,.2f}" if value >= 1000 else f"{value:,.4f}"


def _parse_number(raw: str) -> Optional[float]:
    try:
        return float((raw or "").strip().rstrip("%").replace(",", "."))
    except ValueError:
        return None


def _parse_tp_sl(text: str) -> Optional[tuple[Optional[float], Optional[float]]]:
    """'100/40' -> (100, 40), '100' -> (100, None), '/40' -> (None, 40)."""
    tp_text, _, sl_text = text.partition("/")
    tp = sl = None
    if tp_text.strip():
        tp = _parse_number(tp_text)
        if tp is None or tp <= 0:
            return None
    if sl_text.strip():
        sl = _parse_number(sl_text)
        if sl is None or not 0 < sl < 100:
            return None
    if tp is None and sl is None:
        return None
    return tp, sl


def _is_pubkey(text: str) -> bool:
    try:
        Pubkey.from_string(text.strip())
        return True
    except Exception:  # noqa: BLE001
        return False


class TelegramTokenRejected(Exception):
    """Telegram refused TELEGRAM_BOT_TOKEN. Retrying cannot fix that."""


class TelegramUI:
    def __init__(self, settings, store, trader, safety, sol_price, risk) -> None:
        self._settings = settings
        self._store = store
        self._trader = trader
        self._safety = safety
        self._sol_price = sol_price
        self._risk = risk
        self._app: Optional[Application] = None
        self.book = None
        self.auto = None
        self._buying: set[str] = set()
        self._tasks: set[asyncio.Task] = set()

    def bind(self, book, auto) -> None:
        self.book = book
        self.auto = auto

    def _spawn(self, coro) -> None:
        task = asyncio.create_task(coro)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    # ----------------------------------------------------------------- auth
    def _authorized(self, update: Update) -> bool:
        chat = update.effective_chat
        return chat is not None and chat.id == self._settings.telegram_chat_id_int

    # ------------------------------------------------------------- outbound
    async def notify(self, text: str, markup: Optional[InlineKeyboardMarkup] = None) -> Optional[int]:
        if self._app is None:
            return None
        try:
            message = await self._app.bot.send_message(
                chat_id=self._settings.telegram_chat_id_int,
                text=text,
                parse_mode=ParseMode.HTML,
                reply_markup=markup,
                disable_web_page_preview=True,
            )
            return message.message_id
        except Exception as exc:  # noqa: BLE001
            _log.error("Could not send Telegram message: %r", exc)
            return None

    async def _edit(self, message_id: Optional[int], text: str, markup: Optional[InlineKeyboardMarkup] = None) -> bool:
        if self._app is None or message_id is None:
            return False
        try:
            await self._app.bot.edit_message_text(
                chat_id=self._settings.telegram_chat_id_int,
                message_id=message_id,
                text=text,
                parse_mode=ParseMode.HTML,
                reply_markup=markup,
                disable_web_page_preview=True,
            )
            return True
        except BadRequest as exc:
            if "not modified" in str(exc).lower():
                return True
            _log.warning("Could not edit message %s: %r", message_id, exc)
            return False
        except Exception as exc:  # noqa: BLE001
            _log.warning("Could not edit message %s: %r", message_id, exc)
            return False

    async def _delete(self, message_id: Optional[int]) -> None:
        if self._app is None or message_id is None:
            return
        with contextlib.suppress(Exception):
            await self._app.bot.delete_message(chat_id=self._settings.telegram_chat_id_int, message_id=message_id)

    # ------------------------------------------------- position callbacks
    async def show_new_position(self, position: Position) -> None:
        position.message_id = await self.notify(self._render_position(position), self._position_keyboard(position.mint))

    async def position_changed(self, position: Position) -> None:
        await self._edit(position.message_id, self._render_position(position), self._position_keyboard(position.mint))

    async def position_closed(self, position: Position, text: str) -> None:
        await self._edit(position.message_id, text, None)

    # ------------------------------------------------------------ rendering
    def _mode_tag(self) -> str:
        return "🧪 paper mode" if self._settings.runtime.dry_run else "🔴 LIVE"

    @staticmethod
    def _position_keyboard(mint: str) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [
                [InlineKeyboardButton(f"Sell {pct}%", callback_data=f"sell:{mint}:{pct}") for pct in config.FREE_SELL_PERCENTS],
                [
                    InlineKeyboardButton("🎯 Take profit", callback_data=f"tp:{mint}"),
                    InlineKeyboardButton("🛑 Stop loss", callback_data=f"sl:{mint}"),
                ],
            ]
        )

    def _render_position(self, p: Position) -> str:
        head = "🧪 <b>PAPER BUY</b>" if p.paper else "✅ <b>BOUGHT</b>"
        lines = [
            f"{head} {_esc(p.name)} ({_esc(p.symbol)})",
            f"<code>{p.mint}</code>",
            f"Spent {p.sol_spent:.4f} SOL → {_fmt_amount(p.entry_amount_tokens)} {_esc(p.symbol)}",
            f"Entry {_fmt_price(p.entry_price_usd)}",
        ]
        lines.extend(p.details)
        if p.take_profit_pct is not None or p.stop_loss_pct is not None:
            tp = f"+{p.take_profit_pct:g}%" if p.take_profit_pct is not None else "off"
            sl = f"-{p.stop_loss_pct:g}%" if p.stop_loss_pct is not None else "off"
            lines.append(f"🎯 TP {tp} · 🛑 SL {sl}")
        if p.tokens_raw < p.entry_tokens_raw:
            lines.append(f"📊 Holding {p.remaining_pct:.0f}% · realized {p.realized_sol:+.4f} SOL")
        if p.warnings:
            lines.append("⚠️ " + ", ".join(_esc(w) for w in p.warnings))
        links = []
        if p.buy_signature:
            links.append(f"<a href=\"https://solscan.io/tx/{p.buy_signature}\">tx</a>")
        links.append(f"<a href=\"https://dexscreener.com/solana/{p.mint}\">chart</a>")
        lines.append(" · ".join(links))
        return "\n".join(lines)

    def _render_holding(self, p: Position) -> str:
        source = "auto" if p.source == SOURCE_AUTO else "manual"
        mode = "🧪 paper" if p.paper else "🔴 live"
        change = p.change_pct(p.last_price_usd)
        lines = [
            f"<b>{_esc(p.symbol)}</b> · {mode} · {source}",
            f"<code>{p.mint}</code>",
            f"Entry {_fmt_price(p.entry_price_usd)} · Now {_fmt_price(p.last_price_usd)}"
            + (f" ({change:+.1f}%)" if change is not None else ""),
        ]
        sol_usd = self._sol_price.get()
        value = (
            f" · worth ~{p.amount_tokens * p.last_price_usd / sol_usd:.4f} SOL"
            if p.last_price_usd and sol_usd
            else ""
        )
        lines.append(f"Holding {_fmt_amount(p.amount_tokens)} ({p.remaining_pct:.0f}% of entry){value}")
        if p.take_profit_pct is not None or p.stop_loss_pct is not None:
            tp = f"+{p.take_profit_pct:g}%" if p.take_profit_pct is not None else "off"
            sl = f"-{p.stop_loss_pct:g}%" if p.stop_loss_pct is not None else "off"
            lines.append(f"🎯 TP {tp} · 🛑 SL {sl}")
        return "\n".join(lines)

    # ----------------------------------------------------------------- menu
    def _menu_text(self) -> str:
        mode = "Manual" if self._store.mode == MODE_MANUAL else "Auto"
        lines = [
            f"👺 <b>Gobli Free</b> · {self._mode_tag()}",
            "",
            "Two snipers in one bot. Pick how you want to hunt:",
            "",
            "🎯 <b>Manual</b> - paste a token address, I buy it.",
            "🤖 <b>Auto</b> - set one rule (a creator's wallet or a ticker) and I watch pump.fun launches for you.",
            "",
            f"You're in <b>{mode}</b> mode.",
        ]
        if not self._settings.has_wallet:
            lines += [
                "",
                "🧪 No wallet in .env, so this is paper trading: real Jupiter prices, nothing sent. "
                "Add a dedicated hot wallet's key and restart to trade for real.",
            ]
        elif self._settings.runtime.dry_run:
            lines += ["", "🧪 Paper mode: real prices, nothing sent. /live when you're ready to spend SOL."]
        lines += [
            "",
            f"<i>Free edition: {config.FREE_MAX_OPEN_POSITIONS} open positions, 1 auto rule, standard RPC sending. /upgrade to see Gobli Pro.</i>",
        ]
        return "\n".join(lines)

    def _menu_keyboard(self) -> InlineKeyboardMarkup:
        manual = "🎯 Manual ✓" if self._store.mode == MODE_MANUAL else "🎯 Manual"
        auto = "🤖 Auto ✓" if self._store.mode == MODE_AUTO else "🤖 Auto"
        return InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(manual, callback_data="mode:manual"),
                    InlineKeyboardButton(auto, callback_data="mode:auto"),
                ],
                [
                    InlineKeyboardButton("📊 Positions", callback_data="menu:positions"),
                    InlineKeyboardButton("⚙️ Settings", callback_data="menu:config"),
                ],
                [InlineKeyboardButton("⚡ Gobli Pro", callback_data="menu:upgrade")],
            ]
        )

    async def cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        context.user_data.pop("pending", None)
        await self.notify(self._menu_text(), self._menu_keyboard())

    # ---------------------------------------------------------------- modes
    async def _switch_to_manual(self) -> str:
        self._store.set_mode(MODE_MANUAL)
        if self.auto is not None:
            await self.auto.sync()
        lines = [
            f"🎯 <b>Manual mode</b> · {self._mode_tag()}",
            "",
            f"Paste a token's mint address and I buy {self._settings.runtime.buy_amount_sol:g} SOL of it.",
            "Change the size with /setbuy.",
        ]
        rule = self._store.rule
        if rule is not None and rule.active:
            lines.append("\nYour auto rule is saved, but not watching while you're in Manual.")
        return "\n".join(lines)

    async def _switch_to_auto(self) -> None:
        self._store.set_mode(MODE_AUTO)
        if self.auto is not None:
            await self.auto.sync()
        text, markup = self._auto_view()
        await self.notify(text, markup)

    def _auto_view(self) -> tuple[str, InlineKeyboardMarkup]:
        rule = self._store.rule
        lines = [f"🤖 <b>Auto mode</b> · {self._mode_tag()}", ""]
        rows: list[list[InlineKeyboardButton]] = []
        new_rule_row = [
            InlineKeyboardButton("🎯 Creator wallet", callback_data="new:creator"),
            InlineKeyboardButton("🔤 Ticker", callback_data="new:ticker"),
        ]

        if rule is None:
            lines += [
                "No rule yet. What do you know about the coin you want?",
                "",
                "🎯 <b>Creator wallet</b> - I buy the first coin that wallet launches, as soon as it's routable.",
                "🔤 <b>Ticker</b> - I watch for that exact ticker and buy once real SOL is in its curve, "
                "which filters out the copycats.",
            ]
            rows.append(new_rule_row)
        else:
            lines.append(f"<b>Rule</b> {rule.status}\n{_esc(rule.describe())}")
            feed = self.auto.feed if self.auto is not None else None
            if feed is not None and self._store.killed:
                lines.append("\n🛑 Kill switch is on - /resume to release it.")
            elif feed is not None and feed.unavailable_reason:
                lines.append(f"\n⛔ Launch feed refused: {_esc(feed.unavailable_reason)}")
            elif feed is not None and feed.running:
                state = "🟢 live" if feed.connected else "🟡 connecting"
                lines.append(f"\nLaunch feed: {state} · {feed.launches_seen:,} launches seen")
            elif rule.active:
                lines.append("\nLaunch feed: starting…")
            if self.auto is not None and self.auto.watching:
                watching = [
                    f"• {_esc(w.launch.symbol)} - {w.last_sol_in_curve:.2f}/{rule.min_sol_in_curve:g} SOL, "
                    f"{max(0, int((w.deadline - time.time()) / 60))}m left"
                    for w in self.auto.watching.values()
                ]
                lines.append("\n<b>Watching</b>\n" + "\n".join(watching))

            if rule.active:
                rows.append(
                    [
                        InlineKeyboardButton("⏸ Pause", callback_data="rule:pause"),
                        InlineKeyboardButton("🗑 Delete", callback_data="rule:delete"),
                    ]
                )
                rows.append([InlineKeyboardButton("➕ Replace with a new rule", callback_data="rule:new")])
            elif not rule.enabled and not rule.expired and not rule.exhausted:
                rows.append(
                    [
                        InlineKeyboardButton("▶️ Arm", callback_data="rule:arm"),
                        InlineKeyboardButton("🗑 Delete", callback_data="rule:delete"),
                    ]
                )
                rows.append([InlineKeyboardButton("➕ Replace with a new rule", callback_data="rule:new")])
            else:
                lines.append("\nSet up the next one:")
                rows.append(new_rule_row)

        rows.append([InlineKeyboardButton("🎯 Switch to Manual", callback_data="mode:manual")])
        return "\n".join(lines), InlineKeyboardMarkup(rows)

    async def cmd_manual(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        context.user_data.pop("pending", None)
        await self.notify(await self._switch_to_manual())

    async def cmd_auto(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        context.user_data.pop("pending", None)
        await self._switch_to_auto()

    async def cmd_rule(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        text, markup = self._auto_view()
        await self.notify(text, markup)

    # -------------------------------------------------------- rule builder
    async def _start_rule(self, context: ContextTypes.DEFAULT_TYPE, kind: str) -> None:
        context.user_data["pending"] = {"flow": "rule", "step": "target", "draft": {"kind": kind}}
        if kind == rules.KIND_CREATOR:
            await self.notify(
                "🎯 <b>Creator rule</b>\n\n"
                "Send the creator's wallet address. I buy the first coin it launches on pump.fun, "
                "as soon as Jupiter can route it.\n\n/cancel to stop."
            )
        else:
            await self.notify(
                "🔤 <b>Ticker rule</b>\n\n"
                "Send the ticker to watch for, e.g. <code>HELLO</code>. Exact match - case and a "
                "leading $ don't matter.\n\n"
                "Anyone can mint a fake with the same ticker for pennies, so I never buy a ticker at "
                "launch. Next I'll ask how much real SOL must be in its curve first.\n\n/cancel to stop."
            )

    async def _rule_step(self, update: Update, context: ContextTypes.DEFAULT_TYPE, pending: dict) -> None:
        text = (update.effective_message.text or "").strip()
        draft = pending["draft"]
        step = pending["step"]
        runtime = self._settings.runtime

        if step == "target":
            if draft["kind"] == rules.KIND_CREATOR:
                if not _is_pubkey(text):
                    await self.notify("That isn't a Solana wallet address. Try again, or /cancel.")
                    return
                draft["target"] = text
                pending["step"] = "buy"
            else:
                ticker = normalize_ticker(text.replace("*", "").replace("_", ""))
                if not ticker or " " in ticker:
                    await self.notify("Send a single ticker, like <code>HELLO</code>. Or /cancel.")
                    return
                if len(ticker) > config.TICKER_MAX_LENGTH:
                    await self.notify(f"Tickers are at most {config.TICKER_MAX_LENGTH} characters. Try again.")
                    return
                if is_mixed_script(ticker):
                    await self.notify(
                        "That ticker mixes alphabets (e.g. a Cyrillic letter among Latin ones) - the classic "
                        "impersonation trick. Send it in one alphabet."
                    )
                    return
                draft["target"] = ticker
                pending["step"] = "min_sol"
                await self.notify(
                    f"Watching for <b>{_esc(ticker)}</b>.\n\n"
                    "<b>Minimum SOL in its bonding curve</b> before I buy?\n\n"
                    "This is real money that buyers have put in. A fake sits near zero. Something between "
                    "<code>3</code> and <code>30</code> is a sensible start."
                )
                return

        elif step == "min_sol":
            value = _parse_number(text)
            if value is None or not 0 < value < MAX_MIN_SOL_IN_CURVE:
                await self.notify(f"Send a number of SOL between 0 and {MAX_MIN_SOL_IN_CURVE:g}, e.g. <code>5</code>.")
                return
            draft["min_sol"] = value
            pending["step"] = "buy"

        elif step == "buy":
            if text.lower() not in SKIP_WORDS:
                value = _parse_number(text)
                if value is None or value <= 0:
                    await self.notify("Send an amount of SOL above 0, or <code>skip</code>.")
                    return
                draft["buy"] = value
            pending["step"] = "tpsl"
            await self.notify(
                "<b>Take profit / stop loss?</b>\n\n"
                "<code>100/40</code> = sell everything at +100%, or at -40%.\n"
                "<code>100</code> = take profit only · <code>/40</code> = stop loss only · "
                "<code>skip</code> = neither."
            )
            return

        elif step == "tpsl":
            if text.lower() not in SKIP_WORDS:
                parsed = _parse_tp_sl(text)
                if parsed is None:
                    await self.notify("Send something like <code>100/40</code>, or <code>skip</code>.")
                    return
                draft["tp"], draft["sl"] = parsed
            pending["step"] = "expiry"
            await self.notify(
                "<b>How long should this rule live?</b> Every rule expires - a forgotten rule that fires "
                "weeks later is how people lose money in their sleep.",
                InlineKeyboardMarkup(
                    [[InlineKeyboardButton(label, callback_data=f"exp:{label}") for label in config.FREE_RULE_EXPIRY_CHOICES]]
                ),
            )
            return

        elif step in ("expiry", "confirm"):
            await self.notify("Tap one of the buttons above, or /cancel.")
            return

        if pending["step"] == "buy":
            await self.notify(
                f"<b>How much SOL per buy?</b>\n\nDefault is {runtime.buy_amount_sol:g} SOL. "
                f"Send a number, or <code>skip</code> for the default."
            )

    def _draft_rule(self, draft: dict) -> rules.Rule:
        return rules.Rule(
            kind=draft["kind"],
            target=draft["target"],
            expires_at=time.time() + config.FREE_RULE_EXPIRY_CHOICES[draft["expiry"]],
            min_sol_in_curve=draft.get("min_sol"),
            buy_amount_sol=draft.get("buy"),
            take_profit_pct=draft.get("tp"),
            stop_loss_pct=draft.get("sl"),
        )

    async def _on_expiry(self, context: ContextTypes.DEFAULT_TYPE, label: str) -> None:
        pending = context.user_data.get("pending")
        if not pending or pending.get("flow") != "rule" or label not in config.FREE_RULE_EXPIRY_CHOICES:
            return
        pending["draft"]["expiry"] = label
        pending["step"] = "confirm"
        rule = self._draft_rule(pending["draft"])
        notes = []
        existing = self._store.rule
        if existing is not None and existing.active:
            notes.append("⚠️ The free edition holds one rule - arming this one replaces your current rule.")
        notes.append(
            "🧪 Paper mode - I'll price every buy from live quotes and send nothing."
            if self._settings.runtime.dry_run
            else "🔴 <b>LIVE</b> - this spends real SOL, with no confirmation per trade."
        )
        await self.notify(
            f"<b>Ready to arm</b>\n\n{_esc(rule.describe())}\n\n" + "\n".join(notes),
            InlineKeyboardMarkup(
                [[
                    InlineKeyboardButton("✅ Arm it", callback_data="arm:yes"),
                    InlineKeyboardButton("✖️ Cancel", callback_data="arm:no"),
                ]]
            ),
        )

    async def _on_arm(self, context: ContextTypes.DEFAULT_TYPE, yes: bool) -> None:
        pending = context.user_data.pop("pending", None)
        if not pending or pending.get("flow") != "rule" or "expiry" not in pending.get("draft", {}):
            await self.notify("That rule draft is gone - /auto to start again.")
            return
        if not yes:
            await self.notify("Cancelled. Nothing armed.")
            return
        rule = self._draft_rule(pending["draft"])
        problems = rules.validate_rule(rule)
        if problems:
            await self.notify("I can't arm that rule:\n" + "\n".join(f"• {_esc(p)}" for p in problems))
            return
        self._store.set_rule(rule)
        if self.auto is not None:
            await self.auto.drop_watches()
        lines = ["✅ <b>Armed.</b>"]
        if self._store.killed:
            lines.append("🛑 The kill switch is on, so nothing will be bought until you /resume.")
        await self.notify("\n".join(lines))
        await self._switch_to_auto()

    async def _rule_control(self, action: str, context: ContextTypes.DEFAULT_TYPE) -> None:
        rule = self._store.rule
        if action == "new":
            await self.notify(
                "What should the new rule follow?",
                InlineKeyboardMarkup(
                    [[
                        InlineKeyboardButton("🎯 Creator wallet", callback_data="new:creator"),
                        InlineKeyboardButton("🔤 Ticker", callback_data="new:ticker"),
                    ]]
                ),
            )
            return
        if rule is None:
            await self.notify("No rule to change. /auto to set one.")
            return
        if action == "pause":
            rule.enabled = False
            self._store.save()
            await self.notify("⏸ Rule paused.")
        elif action == "arm":
            rule.enabled = True
            self._store.save()
            await self.notify("▶️ Rule armed.")
        elif action == "delete":
            self._store.set_rule(None)
            await self.notify("🗑 Rule deleted.")
        if self.auto is not None:
            await self.auto.sync()
        text, markup = self._auto_view()
        await self.notify(text, markup)

    # ------------------------------------------------------------ text input
    async def on_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        text = (update.effective_message.text or "").strip()

        pending = context.user_data.get("pending")
        if pending is not None:
            if pending.get("flow") == "rule":
                await self._rule_step(update, context, pending)
                return
            if pending.get("flow") == "target":
                if not MINT_RE.match(text):
                    await self._target_step(context, pending, text)
                    return
                # A mint pasted instead of a percent means "buy this" - drop the prompt.
                context.user_data.pop("pending", None)

        if not MINT_RE.match(text):
            await self.notify("Paste a token's mint address to buy it, or /start for the menu.")
            return
        if self._store.mode != MODE_MANUAL:
            await self.notify(
                "You're in <b>Auto</b> mode, so pasted addresses aren't bought.",
                InlineKeyboardMarkup([[InlineKeyboardButton("🎯 Switch to Manual", callback_data="mode:manual")]]),
            )
            return
        if not _is_pubkey(text):
            await self.notify("That doesn't look like a valid mint address.")
            return
        self._spawn(self._manual_buy(text))

    async def _target_step(self, context: ContextTypes.DEFAULT_TYPE, pending: dict, text: str) -> None:
        position = self.book.positions.get(pending["mint"]) if self.book else None
        kind = pending["kind"]
        if position is None:
            context.user_data.pop("pending", None)
            await self.notify("That position is closed.")
            return
        value = _parse_number(text)
        limit_ok = value is not None and (value >= 0 if kind == "tp" else 0 <= value < 100)
        if not limit_ok:
            example = "50 for +50%" if kind == "tp" else "30 for -30%"
            await self.notify(f"Send a percent ({example}), 0 to turn it off, or /cancel.")
            return
        context.user_data.pop("pending", None)
        value = value or None
        if kind == "tp":
            position.take_profit_pct = value
            msg = f"🎯 Take profit set at +{value:g}%" if value else "🎯 Take profit off"
        else:
            position.stop_loss_pct = value
            msg = f"🛑 Stop loss set at -{value:g}%" if value else "🛑 Stop loss off"
        await self.position_changed(position)
        await self.notify(
            f"{msg} for {_esc(position.symbol)}. Checked every {config.FREE_PRICE_CHECK_SECONDS:g}s."
        )

    # ---------------------------------------------------------- manual buy
    async def _manual_buy(self, mint: str) -> None:
        if mint in self._buying or self.book is None:
            return
        self._buying.add(mint)
        try:
            runtime = self._settings.runtime
            paper = runtime.dry_run
            amount = runtime.buy_amount_sol
            balance = 0.0 if paper else await self._trader.get_sol_balance()
            refusal = self._risk.check(
                mint,
                amount,
                # Buys still in flight count too, or pasting several mints at
                # once would slip past the position limit.
                open_positions=len(self.book.positions) + len(self._buying) - 1,
                holding_mint=self.book.holds(mint),
                wallet_balance_sol=balance,
                paper=paper,
                auto=False,
            )
            if refusal is not None:
                await self.notify(f"🚫 Not buying: {_esc(refusal)}")
                return

            started = time.monotonic()
            status_id = await self.notify("🧪 Paper buying…" if paper else "⚡ Buying…")
            safety_task = asyncio.create_task(self._safety.check(mint))
            result = await self._trader.buy(
                mint, amount, runtime.slippage_bps, paper=paper, wait_for_route=3.0, started_at=started
            )
            if not result.ok:
                safety_task.cancel()
                tx = f"\n<a href=\"https://solscan.io/tx/{result.signature}\">tx</a>" if result.signature else ""
                text = f"❌ <b>{'Paper buy' if paper else 'Buy'} failed</b>\n<code>{mint}</code>\n{_esc(result.error)}{tx}"
                if not await self._edit(status_id, text):
                    await self.notify(text)
                return

            report = await safety_task
            if not paper:
                self._store.record_live_spend(amount)

            tokens = result.tokens_raw / (10**result.decimals) if result.decimals else float(result.tokens_raw)
            sol_usd = self._sol_price.get()
            entry_price_usd = (amount * sol_usd / tokens) if tokens and sol_usd else (report.price_usd or 0.0)

            details = []
            market = []
            if report.market_cap_usd is not None:
                market.append(f"MC {_fmt_usd(report.market_cap_usd)}")
            if report.liquidity_usd is not None:
                market.append(f"Liq {_fmt_usd(report.liquidity_usd)}")
            if report.rugcheck_score is not None:
                market.append(f"Rugcheck {report.rugcheck_score:.0f}/100")
            if market:
                details.append(" · ".join(market))
            if result.elapsed_ms:
                details.append(f"🎯 Manual · {'priced' if paper else 'confirmed'} in {result.elapsed_ms / 1000:.1f}s")
            if result.note:
                details.append(f"<i>{_esc(result.note)}</i>")

            position = Position(
                mint=mint,
                name=report.name or "Unknown",
                symbol=report.symbol or mint[:4].upper(),
                decimals=result.decimals,
                entry_tokens_raw=result.tokens_raw,
                tokens_raw=result.tokens_raw,
                sol_spent=amount,
                entry_price_usd=entry_price_usd,
                paper=paper,
                source=SOURCE_MANUAL,
                buy_signature=result.signature,
                details=details,
                warnings=report.warnings(),
            )
            self.book.open(position)
            await self._delete(status_id)
            await self.show_new_position(position)
        except Exception:  # noqa: BLE001
            _log.exception("Manual buy crashed for %s", mint)
            await self.notify("❌ Buy failed: unexpected error (see gobli_free.log)")
        finally:
            self._buying.discard(mint)

    # ------------------------------------------------------------- callbacks
    async def on_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        query = update.callback_query
        data = query.data or ""
        with contextlib.suppress(Exception):
            await query.answer()

        prefix, _, rest = data.partition(":")
        if prefix == "mode":
            context.user_data.pop("pending", None)
            if rest == "manual":
                await self.notify(await self._switch_to_manual())
            else:
                await self._switch_to_auto()
        elif prefix == "menu":
            if rest == "positions":
                await self._show_positions()
            elif rest == "config":
                await self.notify(await self._config_text())
            elif rest == "upgrade":
                await self._show_upgrade()
        elif prefix == "new":
            await self._start_rule(context, rules.KIND_CREATOR if rest == "creator" else rules.KIND_TICKER)
        elif prefix == "exp":
            await self._on_expiry(context, rest)
        elif prefix == "arm":
            await self._on_arm(context, rest == "yes")
        elif prefix == "rule":
            await self._rule_control(rest, context)
        elif prefix == "sell":
            mint, _, pct = rest.partition(":")
            self._spawn(self._sell_flow(mint, int(pct) if pct.isdigit() else 100))
        elif prefix in ("tp", "sl"):
            if self.book is None or rest not in self.book.positions:
                await self.notify("That position is closed.")
                return
            context.user_data["pending"] = {"flow": "target", "kind": prefix, "mint": rest}
            if prefix == "tp":
                await self.notify("Send the take-profit % (e.g. <code>50</code> for +50%), or 0 to turn it off.")
            else:
                await self.notify("Send the stop-loss % (e.g. <code>30</code> for -30%), or 0 to turn it off.")

    async def _sell_flow(self, mint: str, pct: int) -> None:
        if self.book is None:
            return
        status_id = await self.notify(f"⏳ Selling {pct}%…")
        _ok, text = await self.book.sell(mint, pct)
        if not await self._edit(status_id, text):
            await self.notify(text)

    # -------------------------------------------------------------- commands
    async def cmd_positions(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        await self._show_positions()

    async def _show_positions(self) -> None:
        if self.book is None or not self.book.positions:
            await self.notify("No open positions.")
            return
        await self.book.refresh_prices()
        for position in list(self.book.positions.values()):
            await self.notify(self._render_holding(position), self._position_keyboard(position.mint))

    async def cmd_sell(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        if not context.args:
            await self.notify("Usage: <code>/sell &lt;mint&gt;</code> - sells 100%.")
            return
        self._spawn(self._sell_flow(context.args[0].strip(), 100))

    async def cmd_balance(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        if not self._settings.has_wallet:
            await self.notify("No wallet configured - paper mode only.")
            return
        balance = await self._trader.get_sol_balance()
        usd = balance * self._sol_price.get()
        await self.notify(f"💰 <code>{self._trader.pubkey}</code>\n<b>{balance:.4f} SOL</b> (${usd:,.2f})")

    async def _config_text(self) -> str:
        r = self._settings.runtime
        wallet = f"<code>{self._trader.pubkey}</code>" if self._settings.has_wallet else "none (paper only)"
        return (
            f"⚙️ <b>Settings</b>\n\n"
            f"Trading: {self._mode_tag()}\n"
            f"Sniper: {'🎯 Manual' if self._store.mode == MODE_MANUAL else '🤖 Auto'}\n"
            f"Kill switch: {'🛑 ON' if self._store.killed else 'off'}\n"
            f"Wallet: {wallet}\n\n"
            f"Buy amount: {r.buy_amount_sol:g} SOL (/setbuy)\n"
            f"Slippage: manual {r.slippage_bps} bps · auto {r.auto_slippage_bps} bps (/setslippage)\n"
            f"Priority fee: {r.priority_fee_lamports:,} lamports, fixed\n"
            f"Daily cap: {self._store.spent_today:.4f} of {self._settings.max_sol_per_day:g} SOL used\n"
            f"Jupiter: {'API key' if self._settings.jupiter_api_key else 'keyless'}\n\n"
            f"<b>Free edition limits</b>\n"
            f"• {config.FREE_MAX_OPEN_POSITIONS} open positions\n"
            f"• sell {' / '.join(f'{p}%' for p in config.FREE_SELL_PERCENTS)} · TP/SL checked every "
            f"{config.FREE_PRICE_CHECK_SECONDS:g}s\n"
            f"• 1 auto rule, fires once, expires within 24h\n"
            f"• standard RPC sending, fixed priority fee\n\n"
            f"/upgrade to compare with Gobli Pro."
        )

    async def cmd_config(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        await self.notify(await self._config_text())

    async def cmd_setbuy(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        value = _parse_number(context.args[0]) if context.args else None
        if value is None or value <= 0:
            await self.notify("Usage: <code>/setbuy 0.05</code> (amount in SOL)")
            return
        self._settings.runtime.buy_amount_sol = value
        self._store.remember_runtime(self._settings.runtime)
        await self.notify(f"✅ Buy amount is now {value:g} SOL. This survives a restart.")

    async def cmd_setslippage(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        args = list(context.args or [])
        target = "manual"
        if args and args[0].lower() in ("auto", "manual"):
            target = args.pop(0).lower()
        try:
            value = int(args[0])
            if not 1 <= value <= 10000:
                raise ValueError
        except (IndexError, ValueError):
            await self.notify(
                "Usage: <code>/setslippage 500</code> for manual buys, "
                "<code>/setslippage auto 2500</code> for auto snipes (basis points, 100 = 1%)."
            )
            return
        if target == "auto":
            self._settings.runtime.auto_slippage_bps = value
        else:
            self._settings.runtime.slippage_bps = value
        self._store.remember_runtime(self._settings.runtime)
        await self.notify(f"✅ {target.capitalize()} slippage is now {value} bps ({value / 100:g}%).")

    async def cmd_paper(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        self._settings.runtime.dry_run = True
        await self.notify("🧪 Paper mode ON. Trades are priced from live quotes and nothing is sent.")

    async def cmd_live(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        if not self._settings.has_wallet:
            await self.notify(
                "There's no wallet in .env, so paper mode is all there is.\n\n"
                "To trade for real: create a <b>dedicated</b> hot wallet, fund it with only what you "
                "accept losing, put its private key in .env (setup.html does this for you) and restart."
            )
            return
        if not context.args or context.args[0].lower() != "confirm":
            balance = await self._trader.get_sol_balance()
            await self.notify(
                f"This spends real SOL from <code>{self._trader.pubkey}</code> (holding {balance:.4f} SOL). "
                "Auto snipes go out with no confirmation per trade.\n\n"
                "Send <code>/live confirm</code> if you mean it."
            )
            return
        self._settings.runtime.dry_run = False
        note = ""
        if self.book is not None and any(p.paper for p in self.book.positions.values()):
            note = "\nOpen paper positions stay on paper until you sell them."
        await self.notify(f"🔴 <b>LIVE.</b> Buys spend real SOL. /paper to go back.{note}")

    async def cmd_panic(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        context.user_data.pop("pending", None)
        self._store.set_killed(True)
        rule = self._store.rule
        if rule is not None and rule.enabled:
            rule.enabled = False
            self._store.save()
        dropped = await self.auto.drop_watches() if self.auto is not None else 0
        if self.auto is not None:
            await self.auto.sync()
        await self.notify("🛑 Panic - pausing the rule and selling everything…")
        sold, failed = await self.book.sell_all("panic") if self.book is not None else (0, 0)
        await self.notify(
            f"🛑 <b>PANIC</b>\nRule paused, {dropped} watch(es) dropped.\n"
            f"{sold} position(s) sold, {failed} failed.\n"
            "Kill switch is ON - every buy is blocked until /resume."
        )

    async def cmd_resume(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        self._store.set_killed(False)
        await self.notify("Kill switch released. Your auto rule stays paused - /auto to re-arm it.")

    async def cmd_upgrade(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        await self._show_upgrade()

    async def _show_upgrade(self) -> None:
        await self.notify(
            "⚡ <b>What Gobli Pro adds</b>\n\n"
            "Manual and Auto running side by side, not one at a time.\n\n"
            "🎯 <b>Manual</b>\n"
            "• Buys straight at the pump.fun curve, Jupiter for the rest\n"
            "• Helius Sender: staked + Jito routes instead of a plain RPC send\n"
            "• Fresh priority-fee estimate and compute tuning on every swap\n"
            "• 4 safety checks (adds GoPlus and holder concentration)\n"
            "• Sell 25/50/75/100%, add to a position, no position cap\n\n"
            "🤖 <b>Auto</b>\n"
            "• Earlier launch detection, up to Helius' pre-execution feed\n"
            "• Builds the pump.fun buy itself - no aggregator round trip\n"
            "• Unlimited rules, many wallets and tickers each, contains-matching\n"
            "• Max-SOL ceiling, creator-buy cap, instant ticker buys\n\n"
            "Plus bonk.fun launch alerts, PnL share cards and /preflight.\n\n"
            "One-time price, full source, self-hosted. Your keys never leave your machine.",
            InlineKeyboardMarkup(
                [[
                    InlineKeyboardButton("🌐 gobli.io", url=config.UPGRADE_URL),
                    InlineKeyboardButton("💬 Message us", url=config.CONTACT_URL),
                ]]
            ),
        )

    async def cmd_cancel(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        had = context.user_data.pop("pending", None) is not None
        await self.notify("Cancelled." if had else "Nothing to cancel.")

    async def cmd_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._authorized(update):
            return
        await self.notify(
            "📖 <b>Gobli Free</b>\n\n"
            "/start - menu and mode switch\n"
            "/manual - Manual mode: paste a mint address to buy\n"
            "/auto - Auto mode: set or manage your rule\n"
            "/rule - show the auto rule\n\n"
            "/positions - open positions with sell buttons\n"
            "/sell &lt;mint&gt; - sell 100% of a position\n"
            "/balance - wallet balance\n"
            "/config - settings and free-edition limits\n"
            "/setbuy &lt;sol&gt; · /setslippage [auto] &lt;bps&gt;\n\n"
            "/paper - paper trading · /live confirm - real SOL\n"
            "🛑 /panic - pause the rule and sell everything\n"
            "/resume - release the kill switch\n"
            "/upgrade - what Gobli Pro adds\n"
            "/cancel - abandon a half-finished input"
        )

    async def on_error(self, update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        _log.error("Unhandled Telegram update error", exc_info=context.error)

    # ------------------------------------------------------------------ setup
    def build(self) -> Application:
        app = ApplicationBuilder().token(self._settings.telegram_bot_token).build()
        self._app = app
        owner = filters.ChatType.PRIVATE & filters.Chat(chat_id=self._settings.telegram_chat_id_int)

        for name, handler in [
            ("start", self.cmd_start),
            ("manual", self.cmd_manual),
            ("auto", self.cmd_auto),
            ("rule", self.cmd_rule),
            ("rules", self.cmd_rule),
            ("positions", self.cmd_positions),
            ("sell", self.cmd_sell),
            ("balance", self.cmd_balance),
            ("config", self.cmd_config),
            ("setbuy", self.cmd_setbuy),
            ("setslippage", self.cmd_setslippage),
            ("paper", self.cmd_paper),
            ("dry", self.cmd_paper),
            ("live", self.cmd_live),
            ("panic", self.cmd_panic),
            ("resume", self.cmd_resume),
            ("upgrade", self.cmd_upgrade),
            ("cancel", self.cmd_cancel),
            ("help", self.cmd_help),
        ]:
            app.add_handler(CommandHandler(name, handler, filters=owner))
        app.add_handler(CallbackQueryHandler(self.on_callback))
        app.add_handler(MessageHandler(owner & filters.TEXT & ~filters.COMMAND, self.on_text))
        app.add_error_handler(self.on_error)
        return app

    async def run(self, app: Application) -> None:
        """Run polling inside the process's event loop, retrying on startup failures.

        The startup handshake makes real calls to api.telegram.org and can
        fail on a transient DNS or connectivity blip. Retry with capped
        backoff rather than take the whole process down.
        """
        delay = config.TELEGRAM_RECONNECT_BASE_DELAY_SECONDS
        while True:
            try:
                await app.initialize()
                await app.start()
                await app.updater.start_polling(drop_pending_updates=True)
                _log.info("Telegram bot polling")
                delay = config.TELEGRAM_RECONNECT_BASE_DELAY_SECONDS
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                raise
            except InvalidToken as exc:
                raise TelegramTokenRejected(str(exc)) from exc
            except Exception:  # noqa: BLE001
                _log.warning("Telegram connection failed, retrying in %.1fs", delay, exc_info=True)
            finally:
                for cleanup in (app.updater.stop, app.stop, app.shutdown):
                    with contextlib.suppress(Exception):
                        await cleanup()
            await asyncio.sleep(delay)
            delay = min(delay * 2, config.TELEGRAM_RECONNECT_MAX_DELAY_SECONDS)
