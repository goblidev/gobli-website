"""
Everything Gobli Free remembers across a restart, in one small JSON file.

  - which mode you were in (manual or auto) and the auto rule
  - the day's live spend, so a crash loop can't reset the daily cap
  - mints the auto mode has already bought, so it never buys one twice
  - the kill switch
  - buy size and slippage changed from Telegram

Paper/live is deliberately NOT remembered: a restart always comes back in the
mode .env declares, so an unattended reboot can never bring the bot up live
because of a switch flipped days ago.

Open positions are not remembered either. A restart stops tracking them; the
tokens stay in the wallet.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Optional

import config
from logger import get_logger
from rules import Rule

_log = get_logger(__name__)

MODE_MANUAL = "manual"
MODE_AUTO = "auto"


class Store:
    def __init__(self, path: Path) -> None:
        self._path = Path(path)
        self.mode: str = MODE_MANUAL
        self.rule: Optional[Rule] = None
        self.day: str = ""
        self.sol_spent_today: float = 0.0
        self.bought_mints: list[str] = []
        self.killed: bool = False
        self.buy_amount_sol: Optional[float] = None
        self.slippage_bps: Optional[int] = None
        self.auto_slippage_bps: Optional[int] = None
        self.load()

    # ----------------------------------------------------------- persistence
    def load(self) -> None:
        if self._path.exists():
            try:
                raw = json.loads(self._path.read_text(encoding="utf-8"))
                self.mode = raw.get("mode") if raw.get("mode") in (MODE_MANUAL, MODE_AUTO) else MODE_MANUAL
                self.rule = Rule.from_dict(raw["rule"]) if raw.get("rule") else None
                self.day = str(raw.get("day", ""))
                self.sol_spent_today = float(raw.get("sol_spent_today", 0.0))
                self.bought_mints = [str(m) for m in raw.get("bought_mints") or []]
                self.killed = bool(raw.get("killed", False))
                self.buy_amount_sol = raw.get("buy_amount_sol")
                self.slippage_bps = raw.get("slippage_bps")
                self.auto_slippage_bps = raw.get("auto_slippage_bps")
            except (OSError, ValueError, KeyError, TypeError) as exc:
                _log.error("Could not read %s (%s) - starting from a clean state", self._path, exc)
        self._roll_day()

    def save(self) -> None:
        payload = {
            "mode": self.mode,
            "rule": self.rule.to_dict() if self.rule else None,
            "day": self.day,
            "sol_spent_today": self.sol_spent_today,
            # Bounded: this list only exists to stop a repeat buy of the same
            # mint, and old entries stop mattering once a coin is long dead.
            "bought_mints": self.bought_mints[-2000:],
            "killed": self.killed,
            "buy_amount_sol": self.buy_amount_sol,
            "slippage_bps": self.slippage_bps,
            "auto_slippage_bps": self.auto_slippage_bps,
        }
        tmp = self._path.with_suffix(self._path.suffix + ".tmp")
        try:
            tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            tmp.replace(self._path)
        except OSError as exc:
            _log.error("Could not save state to %s: %s", self._path, exc)

    def _roll_day(self) -> None:
        today = time.strftime("%Y-%m-%d", time.gmtime())
        if self.day != today:
            self.day = today
            self.sol_spent_today = 0.0
            self.save()

    # -------------------------------------------------------------- runtime
    def apply_runtime_overrides(self, runtime) -> None:
        """Reapply buy size and slippage changed from Telegram before a restart."""
        if isinstance(self.buy_amount_sol, (int, float)) and self.buy_amount_sol > 0:
            runtime.buy_amount_sol = float(self.buy_amount_sol)
        if isinstance(self.slippage_bps, int) and 1 <= self.slippage_bps <= 10000:
            runtime.slippage_bps = self.slippage_bps
        if isinstance(self.auto_slippage_bps, int) and 1 <= self.auto_slippage_bps <= 10000:
            runtime.auto_slippage_bps = self.auto_slippage_bps

    def remember_runtime(self, runtime) -> None:
        self.buy_amount_sol = runtime.buy_amount_sol
        self.slippage_bps = runtime.slippage_bps
        self.auto_slippage_bps = runtime.auto_slippage_bps
        self.save()

    # ----------------------------------------------------------------- mode
    def set_mode(self, mode: str) -> None:
        self.mode = mode
        self.save()

    def set_rule(self, rule: Optional[Rule]) -> None:
        self.rule = rule
        self.save()

    # ----------------------------------------------------------------- risk
    @property
    def spent_today(self) -> float:
        self._roll_day()
        return self.sol_spent_today

    def record_live_spend(self, amount_sol: float) -> None:
        self._roll_day()
        self.sol_spent_today += amount_sol
        self.save()

    def record_auto_buy(self, mint: str) -> None:
        if mint not in self.bought_mints:
            self.bought_mints.append(mint)
        if self.rule is not None:
            self.rule.buys_done += 1
        self.save()

    def set_killed(self, killed: bool) -> None:
        self.killed = killed
        self.save()
