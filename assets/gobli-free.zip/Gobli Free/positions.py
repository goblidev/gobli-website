"""
Open positions, shared by both modes.

A position opened by the manual mode and one opened by the auto mode are the
same thing from here on: both show up in /positions, both get sell buttons,
and both are watched for take-profit and stop-loss. A paper position is
always closed on paper, even if live mode is switched on afterwards - it
never held real tokens.

Positions live in memory. A restart stops tracking them; the tokens stay in
the wallet.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Optional

import config
from jupiter import JupiterClient
from logger import get_logger
from trader import Trader

_log = get_logger(__name__)

SOURCE_MANUAL = "manual"
SOURCE_AUTO = "auto"

_EXIT_RETRY_SECONDS = 30.0


@dataclass
class Position:
    mint: str
    name: str
    symbol: str
    decimals: int
    entry_tokens_raw: int
    tokens_raw: int
    # SOL that went into the entry. Cost basis for every partial sell is
    # taken pro rata from this.
    sol_spent: float
    entry_price_usd: float
    paper: bool
    source: str
    take_profit_pct: Optional[float] = None
    stop_loss_pct: Optional[float] = None
    realized_sol: float = 0.0
    proceeds_sol: float = 0.0
    buy_signature: Optional[str] = None
    opened_at: float = field(default_factory=time.time)
    message_id: Optional[int] = None
    last_price_usd: Optional[float] = None
    # After a failed take-profit/stop-loss exit, the next attempt waits until
    # this monotonic time, so a coin with no route doesn't retry every pass.
    exit_retry_at: float = 0.0
    # Shown on the position message only.
    details: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def amount_tokens(self) -> float:
        return self.tokens_raw / (10**self.decimals)

    @property
    def entry_amount_tokens(self) -> float:
        return self.entry_tokens_raw / (10**self.decimals)

    @property
    def remaining_pct(self) -> float:
        return self.tokens_raw / self.entry_tokens_raw * 100 if self.entry_tokens_raw else 0.0

    def change_pct(self, price_usd: Optional[float]) -> Optional[float]:
        if price_usd is None or self.entry_price_usd <= 0:
            return None
        return (price_usd - self.entry_price_usd) / self.entry_price_usd * 100

    def cost_basis(self, raw_amount: int) -> float:
        if not self.entry_tokens_raw:
            return 0.0
        return self.sol_spent * (raw_amount / self.entry_tokens_raw)


class PositionBook:
    """Holds positions, sells them, and runs the take-profit / stop-loss loop.

    `ui` is the Telegram layer. It must provide:
        notify(text)                         -> send a message
        position_changed(position)           -> refresh a position's message
        position_closed(position, text)      -> a position was fully sold
    """

    def __init__(self, settings, trader: Trader, jupiter: JupiterClient, ui) -> None:
        self._settings = settings
        self._trader = trader
        self._jupiter = jupiter
        self._ui = ui
        self.positions: dict[str, Position] = {}
        self._selling: set[str] = set()

    def open(self, position: Position) -> None:
        self.positions[position.mint] = position

    def holds(self, mint: str) -> bool:
        return mint in self.positions

    def _slippage_for(self, position: Position) -> int:
        runtime = self._settings.runtime
        return runtime.auto_slippage_bps if position.source == SOURCE_AUTO else runtime.slippage_bps

    # ---------------------------------------------------------------- selling
    async def sell(self, mint: str, pct: int, reason: Optional[str] = None) -> tuple[bool, str]:
        """Sell pct% of the position's entry size. Returns (ok, summary)."""
        position = self.positions.get(mint)
        if position is None:
            return False, "No open position for that coin."
        if mint in self._selling:
            return False, "A sell for this position is already running."

        self._selling.add(mint)
        try:
            if pct >= 100:
                raw_amount = position.tokens_raw
                if not position.paper:
                    # Sell what the chain says is there, not what was tracked:
                    # a sell for more than the real balance fails outright.
                    state = await self._trader.get_token_balance(mint)
                    if state is None:
                        _log.warning("Balance lookup failed for %s - selling the tracked amount", mint)
                    else:
                        raw_amount = state[0]
            else:
                raw_amount = min(position.entry_tokens_raw * pct // 100, position.tokens_raw)

            if raw_amount <= 0:
                if pct >= 100 and not position.paper:
                    self.positions.pop(mint, None)
                    return False, f"No {_plain(position.symbol)} left in the wallet - stopped tracking it."
                return False, "Nothing left to sell."

            result = await self._trader.sell(mint, raw_amount, self._slippage_for(position), paper=position.paper)
            if not result.ok:
                return False, f"❌ Sell failed for {_plain(position.symbol)}: {result.error}"

            cost = position.cost_basis(min(raw_amount, position.tokens_raw))
            pnl = result.sol_amount - cost
            pnl_pct = (pnl / cost * 100) if cost else 0.0
            position.tokens_raw = 0 if pct >= 100 else max(position.tokens_raw - raw_amount, 0)
            position.realized_sol += pnl
            position.proceeds_sol += result.sol_amount

            tx = f"\n<a href=\"https://solscan.io/tx/{result.signature}\">tx</a>" if result.signature else ""
            tag = "🧪 PAPER " if position.paper else ""
            label = f" - {reason}" if reason else ""

            if position.tokens_raw <= 0:
                self.positions.pop(mint, None)
                total_pct = position.realized_sol / position.sol_spent * 100 if position.sol_spent else 0.0
                text = (
                    f"{tag}💰 <b>SOLD 100%</b> {_plain(position.symbol)}{label}\n"
                    f"In: {position.sol_spent:.4f} SOL · Out: {position.proceeds_sol:.4f} SOL\n"
                    f"PnL: <b>{position.realized_sol:+.4f} SOL ({total_pct:+.1f}%)</b>{tx}\n\n"
                    f"<i>Gobli Free · gobli.io</i>"
                )
                await self._ui.position_closed(position, text)
                return True, text

            await self._ui.position_changed(position)
            text = (
                f"{'🧪' if position.paper else '✅'} Sold {pct}% of {_plain(position.symbol)}{label}"
                f"{' (paper)' if position.paper else ''}\n"
                f"Received {result.sol_amount:.4f} SOL · PnL on this sell {pnl:+.4f} SOL ({pnl_pct:+.1f}%){tx}"
            )
            return True, text
        except Exception:  # noqa: BLE001
            _log.exception("Sell failed unexpectedly for %s (pct=%s)", mint, pct)
            return False, "Sell failed: unexpected error (see gobli_free.log)"
        finally:
            self._selling.discard(mint)

    async def sell_all(self, reason: str) -> tuple[int, int]:
        """Sell every position. Returns (sold, failed)."""
        sold = failed = 0
        for mint in list(self.positions):
            ok, text = await self.sell(mint, 100, reason)
            if ok:
                sold += 1
            else:
                failed += 1
                await self._ui.notify(text)
        return sold, failed

    # ------------------------------------------------------------ monitoring
    async def refresh_prices(self) -> None:
        mints = list(self.positions)
        if not mints:
            return
        prices = await self._jupiter.prices_usd(mints)
        for mint, position in list(self.positions.items()):
            if mint in prices:
                position.last_price_usd = prices[mint]

    async def monitor_loop(self) -> None:
        """Check take-profit and stop-loss levels every FREE_PRICE_CHECK_SECONDS.

        One batched price request covers every open position. Gobli Pro
        checks more often.
        """
        while True:
            await asyncio.sleep(config.FREE_PRICE_CHECK_SECONDS)
            armed = [
                p for p in self.positions.values()
                if p.take_profit_pct is not None or p.stop_loss_pct is not None
            ]
            if not armed:
                continue
            try:
                await self.refresh_prices()
                for position in armed:
                    if position.mint not in self.positions or position.mint in self._selling:
                        continue
                    if time.monotonic() < position.exit_retry_at:
                        continue
                    change = position.change_pct(position.last_price_usd)
                    if change is None:
                        continue
                    if position.take_profit_pct is not None and change >= position.take_profit_pct:
                        await self._auto_exit(position, f"take profit hit ({change:+.0f}%)")
                    elif position.stop_loss_pct is not None and change <= -position.stop_loss_pct:
                        await self._auto_exit(position, f"stop loss hit ({change:+.0f}%)")
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                _log.exception("Position monitor pass failed")

    async def _auto_exit(self, position: Position, reason: str) -> None:
        ok, text = await self.sell(position.mint, 100, reason)
        if ok:
            await self._ui.notify(text)
            return
        position.exit_retry_at = time.monotonic() + _EXIT_RETRY_SECONDS
        await self._ui.notify(
            f"⚠️ Auto-sell ({reason}) failed for {_plain(position.symbol)} - retrying in "
            f"{_EXIT_RETRY_SECONDS:.0f}s while the level holds.\n{text}"
        )


def _plain(text: str) -> str:
    """Minimal HTML escaping. Coin names are chosen by whoever launched them."""
    return (text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
