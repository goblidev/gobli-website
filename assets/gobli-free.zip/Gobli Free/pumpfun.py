"""
pump.fun read-side helpers: launch-event decoding, bonding-curve decoding and
ticker normalization.

Gobli Free never builds pump.fun instructions itself - every buy and sell is
routed through Jupiter, which handles pump.fun coins on and off the bonding
curve. This module only reads: what was launched, and how much SOL has gone
into its curve since.

Everything here is pure and synchronous, with no I/O.
"""

from __future__ import annotations

import base64
import binascii
import struct
import unicodedata
from dataclasses import dataclass
from typing import Any, Optional

from solders.pubkey import Pubkey

import config

PUMP_PROGRAM = Pubkey.from_string(config.PUMP_PROGRAM_ID)
WSOL_MINT = Pubkey.from_string(config.SOL_MINT)
TOKEN_PROGRAM = Pubkey.from_string(config.TOKEN_PROGRAM_ID)

LAMPORTS_PER_SOL = 1_000_000_000


def derive_bonding_curve(mint: Pubkey) -> Pubkey:
    address, _ = Pubkey.find_program_address([b"bonding-curve", bytes(mint)], PUMP_PROGRAM)
    return address


class _Reader:
    """Minimal borsh cursor.

    Fields that pump.fun appended in later program upgrades are read
    EOF-tolerantly: an older event or account simply stops before them.
    """

    __slots__ = ("_data", "_pos")

    def __init__(self, data: bytes) -> None:
        self._data = data
        self._pos = 0

    def remaining(self) -> int:
        return len(self._data) - self._pos

    def take(self, n: int) -> bytes:
        if self.remaining() < n:
            raise ValueError(f"truncated: wanted {n} bytes, {self.remaining()} left")
        chunk = self._data[self._pos : self._pos + n]
        self._pos += n
        return chunk

    def u32(self) -> int:
        return struct.unpack_from("<I", self.take(4))[0]

    def u64(self) -> int:
        return struct.unpack_from("<Q", self.take(8))[0]

    def bool_(self) -> bool:
        return self.take(1)[0] != 0

    def pubkey(self) -> Pubkey:
        return Pubkey(self.take(32))

    def string(self, max_len: int) -> str:
        length = self.u32()
        if length > max_len:
            raise ValueError(f"string length {length} exceeds sanity bound {max_len}")
        return self.take(length).decode("utf-8", errors="replace")

    def opt_u64(self, default: int = 0) -> int:
        return self.u64() if self.remaining() >= 8 else default

    def opt_bool(self, default: bool = False) -> bool:
        return self.bool_() if self.remaining() >= 1 else default

    def opt_pubkey(self) -> Optional[Pubkey]:
        return self.pubkey() if self.remaining() >= 32 else None


# --------------------------------------------------------------------------
# Launches
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class Launch:
    """A pump.fun coin creation, decoded from its CreateEvent."""

    signature: str
    slot: int
    mint: str
    bonding_curve: str
    creator: str
    # The wallet that signed the create. Usually the creator, but not always,
    # so creator rules match on either.
    user: str
    name: str
    symbol: str
    is_mayhem_mode: bool
    quote_mint: str
    received_at: float

    @property
    def is_sol_paired(self) -> bool:
        return self.quote_mint == config.SOL_MINT

    @property
    def normalized_symbol(self) -> str:
        return normalize_ticker(self.symbol)


def decode_create_event(blob: bytes, signature: str, slot: int, received_at: float) -> Optional[Launch]:
    """Decode an Anchor CreateEvent. Returns None if the blob isn't one."""
    if len(blob) < 8 or blob[:8] != config.CREATE_EVENT_DISCRIMINATOR:
        return None

    r = _Reader(blob[8:])
    name = r.string(64)
    symbol = r.string(64)
    r.string(400)  # metadata uri - never fetched, an IPFS round trip takes seconds
    mint = r.pubkey()
    bonding_curve = r.pubkey()
    user = r.pubkey()
    creator = r.pubkey()
    r.u64()  # timestamp
    r.u64()  # virtual_token_reserves
    r.u64()  # virtual_sol_reserves
    r.opt_u64()  # real_token_reserves
    r.opt_u64()  # token_total_supply
    r.opt_pubkey()  # token_program
    is_mayhem_mode = r.opt_bool()
    r.opt_bool()  # is_cashback_enabled - deprecated
    quote_mint = r.opt_pubkey() or WSOL_MINT
    if quote_mint == Pubkey.default():
        quote_mint = WSOL_MINT

    return Launch(
        signature=signature,
        slot=slot,
        mint=str(mint),
        bonding_curve=str(bonding_curve),
        creator=str(creator),
        user=str(user),
        name=name,
        symbol=symbol,
        is_mayhem_mode=is_mayhem_mode,
        quote_mint=str(quote_mint),
        received_at=received_at,
    )


def parse_logs_notification(envelope: Any, received_at: float) -> Optional[Launch]:
    """Pull a Launch out of a logsSubscribe notification, if it carries one.

    pump.fun writes its Anchor events into the transaction logs as base64 on
    "Program data:" lines. A failed transaction is skipped outright - its
    create never happened.
    """
    try:
        result = envelope["params"]["result"]
        value = result["value"]
    except (KeyError, TypeError):
        return None
    if not isinstance(value, dict) or value.get("err") is not None:
        return None

    signature = value.get("signature")
    logs = value.get("logs")
    if not signature or not isinstance(logs, list):
        return None

    slot = 0
    context = result.get("context") if isinstance(result, dict) else None
    if isinstance(context, dict) and isinstance(context.get("slot"), int):
        slot = context["slot"]

    for line in logs:
        if not isinstance(line, str) or not line.startswith("Program data: "):
            continue
        try:
            blob = base64.b64decode(line[14:], validate=True)
        except (binascii.Error, ValueError):
            continue
        try:
            launch = decode_create_event(blob, signature, slot, received_at)
        except Exception:  # noqa: BLE001 - a malformed event must not kill the feed
            launch = None
        if launch is not None:
            return launch
    return None


# --------------------------------------------------------------------------
# Bonding curve
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class CurveState:
    virtual_token_reserves: int
    virtual_quote_reserves: int
    real_token_reserves: int
    real_quote_reserves: int
    complete: bool

    @property
    def sol_in_curve(self) -> float:
        """SOL that buyers have actually put into the curve.

        Every pump.fun coin starts from the same virtual reserves with no real
        SOL in it, so the real side is the honest "is anyone buying this"
        number - and the one a copycat coin almost never moves.
        """
        return self.real_quote_reserves / LAMPORTS_PER_SOL


def decode_bonding_curve(data: bytes) -> CurveState:
    """Decode a BondingCurve account (8-byte Anchor discriminator + borsh)."""
    r = _Reader(data[8:])
    virtual_token_reserves = r.u64()
    virtual_quote_reserves = r.u64()
    real_token_reserves = r.u64()
    real_quote_reserves = r.u64()
    r.u64()  # token_total_supply
    complete = r.bool_()
    return CurveState(
        virtual_token_reserves=virtual_token_reserves,
        virtual_quote_reserves=virtual_quote_reserves,
        real_token_reserves=real_token_reserves,
        real_quote_reserves=real_quote_reserves,
        complete=complete,
    )


# --------------------------------------------------------------------------
# Tickers
# --------------------------------------------------------------------------
def normalize_ticker(raw: str) -> str:
    """Canonical form for ticker matching: NFKC, strip $ and whitespace, upper.

    NFKC folds the fullwidth and mathematical-alphanumeric lookalikes that
    would otherwise let "ＨＥＬＬＯ" slip past a match on "HELLO". It does not
    fold Cyrillic homoglyphs - those are handled by is_mixed_script().
    """
    text = unicodedata.normalize("NFKC", raw or "")
    text = text.strip().lstrip("$").strip()
    return text.upper()


def is_mixed_script(raw: str) -> bool:
    """True if the text mixes writing systems.

    A Cyrillic "Е" inside an otherwise-Latin ticker is the standard
    impersonation trick, and normalization cannot fold it because the two are
    genuinely different letters. Rejecting mixed-script tickers is the only
    reliable answer.
    """
    scripts: set[str] = set()
    for ch in raw or "":
        if not ch.isalpha():
            continue
        name = unicodedata.name(ch, "")
        for script in ("LATIN", "CYRILLIC", "GREEK", "ARMENIAN", "HEBREW", "ARABIC"):
            if name.startswith(script):
                scripts.add(script)
                break
    return len(scripts) > 1
