"""
Entry point.

    python main.py

Wires the Telegram bot, both snipers, the position book and the background
loops together, and owns their lifecycle. Every .env value is validated
before anything connects, and the process refuses to start rather than run on
a bad config.
"""

from __future__ import annotations

import asyncio
import sys

try:
    import uvloop

    _HAS_UVLOOP = True
except ImportError:
    _HAS_UVLOOP = False

import aiohttp
from solana.rpc.async_api import AsyncClient
from solana.rpc.commitment import Confirmed

import config
from auto import AutoSniper
from feed import LaunchFeed
from jupiter import JupiterClient, SolPriceCache
from logger import get_logger
from positions import PositionBook
from risk import RiskGate
from safety import SafetyChecker
from state import MODE_MANUAL, Store
from telegram_bot import TelegramTokenRejected, TelegramUI
from trader import Trader

_log = get_logger("main")


def _banner(settings: config.Settings, store: Store, wallet: str | None, balance: float) -> None:
    trading = "PAPER (priced from live quotes, nothing sent)" if settings.runtime.dry_run else "*** LIVE ***"
    print("=" * 64)
    print(" Gobli Free")
    print("=" * 64)
    print(f" Trading:             {trading}")
    print(f" Sniper:              {'Manual' if store.mode == MODE_MANUAL else 'Auto'}")
    if wallet:
        print(f" Wallet:              {wallet[:4]}...{wallet[-4:]}  ({balance:.4f} SOL)")
    else:
        print(" Wallet:              none - paper mode only")
    print(f" Buy amount:          {settings.runtime.buy_amount_sol} SOL")
    print(f" Slippage:            manual {settings.runtime.slippage_bps} bps, auto {settings.runtime.auto_slippage_bps} bps")
    print(f" Priority fee:        {settings.runtime.priority_fee_lamports} lamports")
    print(f" Daily cap:           {settings.max_sol_per_day} SOL")
    print(f" Jupiter:             {'API key' if settings.jupiter_api_key else 'keyless'}")
    print(f" Event loop:          {'uvloop' if _HAS_UVLOOP else 'asyncio (uvloop not on this OS)'}")
    print("=" * 64)


async def run() -> None:
    try:
        settings = config.load_settings()
    except config.ConfigError as exc:
        print(f"\n{exc}\n", file=sys.stderr)
        sys.exit(1)

    store = Store(settings.state_path)
    store.apply_runtime_overrides(settings.runtime)

    connector = aiohttp.TCPConnector(limit=config.HTTP_CONNECTOR_LIMIT, ttl_dns_cache=300)
    http = aiohttp.ClientSession(connector=connector)
    # "confirmed" rather than the library default "finalized", which waits
    # ~13-19s for supermajority lockout. Wallets read confirmed state too.
    rpc = AsyncClient(settings.http_rpc_url, commitment=Confirmed)

    jupiter = JupiterClient(http, settings)
    sol_price = SolPriceCache(jupiter, http)
    await sol_price.refresh_once()
    trader = Trader(http, rpc, jupiter, settings)

    balance = await trader.get_sol_balance()
    wallet = str(trader.pubkey) if trader.pubkey else None
    _banner(settings, store, wallet, balance)

    risk = RiskGate(settings, store)
    if settings.has_wallet:
        refusal = risk.startup_balance_check(balance)
        if refusal is not None:
            print(f"\nRefusing to start: {refusal}\n", file=sys.stderr)
            await rpc.close()
            await http.close()
            sys.exit(1)

    ui = TelegramUI(settings, store, trader, SafetyChecker(http), sol_price, risk)
    app = ui.build()
    book = PositionBook(settings, trader, jupiter, ui)
    feed = LaunchFeed(settings.ws_rpc_url)
    auto = AutoSniper(settings, store, feed, trader, book, risk, sol_price, ui)
    ui.bind(book, auto)

    tasks = [
        asyncio.create_task(sol_price.refresh_forever(), name="sol-price"),
        asyncio.create_task(book.monitor_loop(), name="positions"),
        asyncio.create_task(auto.supervise(), name="auto-supervisor"),
        asyncio.create_task(auto.consume(), name="auto-consumer"),
        asyncio.create_task(auto.watch_loop(), name="auto-watch"),
        asyncio.create_task(ui.run(app), name="telegram"),
    ]

    async def announce() -> None:
        await asyncio.sleep(4)
        mode = "🎯 Manual" if store.mode == MODE_MANUAL else "🤖 Auto"
        wallet_line = f"{balance:.4f} SOL" if settings.has_wallet else "no wallet (paper only)"
        await ui.notify(
            f"🟢 <b>Gobli Free online</b>\n"
            f"{'🧪 paper' if settings.runtime.dry_run else '🔴 LIVE'} · {mode} · {wallet_line}\n\n"
            "/start for the menu, /help for every command."
        )

    tasks.append(asyncio.create_task(announce(), name="announce"))
    _log.info("Started - mode=%s, paper=%s", store.mode, settings.runtime.dry_run)

    exit_code = 0
    try:
        await asyncio.gather(*tasks)
    except TelegramTokenRejected:
        print(
            "\nTelegram rejected TELEGRAM_BOT_TOKEN. Copy the token from @BotFather again "
            "(the whole thing, e.g. 123456789:AA...) into .env and restart.\n",
            file=sys.stderr,
        )
        exit_code = 1
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        await feed.stop()
        await rpc.close()
        await http.close()
    sys.exit(exit_code)


def main() -> None:
    if _HAS_UVLOOP:
        uvloop.install()
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        print("\nShutting down...")


if __name__ == "__main__":
    main()
