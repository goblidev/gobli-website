"""
Trade execution: quote -> build -> sign -> send -> confirm, through Jupiter.

Two modes, chosen per trade:

  Paper  - nothing is sent and no SOL moves. The fill is priced from
           Jupiter's real quote. When a funded wallet is configured, the real
           swap transaction is also built, signed and run through
           simulateTransaction with signature verification on, so a paper buy
           proves the live path works end to end.
  Live   - the signed transaction is sent through the RPC's standard
           sendTransaction and polled until confirmed.

What the free edition leaves out, compared with Gobli Pro: the
priority fee is a fixed amount rather than a fresh estimate per swap, there
is no compute-unit tuning, and transactions go out through a plain RPC send
rather than Helius Sender's staked and Jito routes. Trades still land; they
are just less well placed when the network is busy.

Signing note: the message is signed over to_bytes_versioned(message), never
bytes(message). The wrong byte representation produces a structurally valid
but cryptographically invalid signature, which the network drops at
admission with no fee charged and no status recorded anywhere.
"""

from __future__ import annotations

import asyncio
import base64
import time
from dataclasses import dataclass
from typing import Optional

import aiohttp
from solana.rpc.commitment import Confirmed
from solana.rpc.types import TokenAccountOpts, TxOpts
from solders.message import to_bytes_versioned
from solders.pubkey import Pubkey
from solders.signature import Signature
from solders.transaction import VersionedTransaction

import config
import pumpfun
from jupiter import JupiterClient
from logger import get_logger

_log = get_logger(__name__)

LAMPORTS_PER_SOL = 1_000_000_000

# Errors a simulation can return only because the simulating node hasn't
# caught up with a coin minted moments ago. A live buy is sent forward in
# time, where the coin exists, so these are retried rather than reported.
_LAG_ERRORS = ("IncorrectProgramId", "AccountNotFound", "InvalidAccountData")
# Quote errors that mean "Jupiter hasn't indexed this coin yet" for a fresh
# launch. Matched case-insensitively against both the message and the code.
_NOT_YET_ROUTABLE = (
    "not tradable",
    "token_not_tradable",
    "could not find any route",
    "could_not_find_any_route",
    "no routes found",
    "no_routes_found",
)


@dataclass
class TradeResult:
    ok: bool
    paper: bool
    error: Optional[str] = None
    signature: Optional[str] = None
    # Buy: tokens received. Sell: tokens sold.
    tokens_raw: int = 0
    decimals: int = 0
    # Buy: SOL put in. Sell: SOL received.
    sol_amount: float = 0.0
    elapsed_ms: Optional[float] = None
    note: Optional[str] = None


class Trader:
    def __init__(self, http: aiohttp.ClientSession, rpc, jupiter: JupiterClient, settings) -> None:
        self._http = http
        self._rpc = rpc
        self._jupiter = jupiter
        self._settings = settings
        self._keypair = settings.keypair
        self._timeout = aiohttp.ClientTimeout(total=config.HTTP_REQUEST_TIMEOUT_SECONDS)

    @property
    def pubkey(self) -> Optional[Pubkey]:
        return self._keypair.pubkey() if self._keypair is not None else None

    # ------------------------------------------------------------ read-only
    async def get_sol_balance(self) -> float:
        """Wallet SOL balance. 0.0 with no wallet, or on an RPC failure."""
        if self._keypair is None:
            return 0.0
        try:
            resp = await self._rpc.get_balance(self._keypair.pubkey(), commitment=Confirmed)
            return int(resp.value) / LAMPORTS_PER_SOL
        except Exception:  # noqa: BLE001
            return 0.0

    async def get_token_balance(self, mint: str) -> Optional[tuple[int, int]]:
        """Real on-chain (raw_amount, decimals) the wallet holds of `mint`.

        (0, 0) means the wallet genuinely holds no account for it; None means
        the lookup itself failed. Callers must not collapse the two - an RPC
        hiccup read as "zero" would turn into "nothing left to sell" on a
        position that is still open.

        Looks accounts up by mint rather than deriving the associated account
        address, because that address depends on which token program owns the
        mint (legacy SPL or Token-2022) and the mint filter needs no guess.
        """
        if self._keypair is None:
            return None
        try:
            resp = await self._rpc.get_token_accounts_by_owner_json_parsed(
                self._keypair.pubkey(), TokenAccountOpts(mint=Pubkey.from_string(mint)), commitment=Confirmed
            )
        except Exception:  # noqa: BLE001
            _log.warning("Token balance lookup failed for %s", mint, exc_info=True)
            return None
        best: Optional[tuple[int, int]] = None
        for account in resp.value or []:
            try:
                amount = account.account.data.parsed["info"]["tokenAmount"]
                state = int(amount["amount"]), int(amount["decimals"])
            except Exception:  # noqa: BLE001
                continue
            if best is None or state[0] > best[0]:
                best = state
        return best if best is not None else (0, 0)

    async def get_decimals(self, mint: str) -> int:
        try:
            resp = await self._rpc.get_token_supply(Pubkey.from_string(mint))
            return int(resp.value.decimals)
        except Exception:  # noqa: BLE001
            # Every pump.fun coin has 6 decimals, which is what nearly every
            # coin this bot meets is.
            return 6

    async def read_curve(self, mint: str) -> Optional[pumpfun.CurveState]:
        try:
            resp = await self._rpc.get_account_info(
                pumpfun.derive_bonding_curve(Pubkey.from_string(mint)), encoding="base64", commitment=Confirmed
            )
            if resp.value is None:
                return None
            return pumpfun.decode_bonding_curve(bytes(resp.value.data))
        except Exception as exc:  # noqa: BLE001
            _log.debug("read_curve(%s) failed: %r", mint, exc)
            return None

    # ------------------------------------------------------------- building
    async def _quote(
        self, input_mint: str, output_mint: str, amount_raw: int, slippage_bps: int, wait_seconds: float
    ) -> tuple[Optional[dict], Optional[str]]:
        """Quote, retrying for up to wait_seconds while the coin isn't routable yet."""
        deadline = time.monotonic() + wait_seconds
        while True:
            quote, error = await self._jupiter.quote(input_mint, output_mint, amount_raw, slippage_bps)
            if quote is not None:
                return quote, None
            retryable = any(marker in (error or "").lower() for marker in _NOT_YET_ROUTABLE)
            if not retryable or time.monotonic() >= deadline:
                return None, error
            await asyncio.sleep(config.ROUTE_RETRY_INTERVAL_SECONDS)

    async def _build_signed(self, quote: dict) -> tuple[Optional[VersionedTransaction], Optional[str]]:
        assert self._keypair is not None
        tx_b64, error = await self._jupiter.swap_transaction(
            quote, str(self._keypair.pubkey()), self._settings.runtime.priority_fee_lamports
        )
        if tx_b64 is None:
            return None, error
        try:
            raw_tx = VersionedTransaction.from_bytes(base64.b64decode(tx_b64))
            signature = self._keypair.sign_message(to_bytes_versioned(raw_tx.message))
            return VersionedTransaction.populate(raw_tx.message, [signature]), None
        except Exception as exc:  # noqa: BLE001
            _log.exception("Failed to sign swap transaction")
            return None, f"signing failed: {exc}"

    async def _simulate(self, tx: VersionedTransaction) -> tuple[bool, Optional[str]]:
        body = {
            "jsonrpc": "2.0",
            "id": "simulate",
            "method": "simulateTransaction",
            "params": [
                base64.b64encode(bytes(tx)).decode(),
                {"encoding": "base64", "sigVerify": True, "replaceRecentBlockhash": False, "commitment": "processed"},
            ],
        }
        try:
            async with self._http.post(self._settings.http_rpc_url, json=body, timeout=self._timeout) as resp:
                data = await resp.json(content_type=None)
        except Exception as exc:  # noqa: BLE001
            return False, f"simulation request failed: {exc!r}"
        if "error" in data:
            return False, f"RPC rejected the simulation: {data['error']}"
        value = (data.get("result") or {}).get("value") or {}
        err = value.get("err")
        if err is not None:
            logs = value.get("logs") or []
            _log.info("Simulation failed: %s | %s", err, " | ".join(logs[-4:])[:600])
            return False, str(err)
        return True, None

    async def _send(self, tx: VersionedTransaction) -> Optional[str]:
        try:
            # No max_retries cap: left unset, the RPC node keeps rebroadcasting
            # until the transaction lands or its blockhash expires.
            resp = await self._rpc.send_raw_transaction(bytes(tx), opts=TxOpts(skip_preflight=True))
            signature = str(resp.value)
            _log.info("Sent: https://solscan.io/tx/%s", signature)
            return signature
        except Exception as exc:  # noqa: BLE001
            _log.error("sendTransaction failed: %r", exc)
            return None

    async def _confirm(self, signature: str) -> tuple[bool, Optional[str]]:
        try:
            sig = Signature.from_string(signature)
        except Exception:  # noqa: BLE001
            return False, "invalid signature"
        deadline = time.monotonic() + config.CONFIRM_TIMEOUT_SECONDS
        while time.monotonic() < deadline:
            try:
                resp = await self._rpc.get_signature_statuses([sig], search_transaction_history=True)
                status = resp.value[0]
            except Exception:  # noqa: BLE001
                status = None
            if status is not None:
                if status.err is not None:
                    return False, f"failed on-chain: {status.err}"
                if status.confirmation_status is not None:
                    return True, None
            await asyncio.sleep(config.CONFIRM_POLL_INTERVAL_SECONDS)
        return False, "not confirmed in time - check the transaction on Solscan before retrying"

    async def _received_tokens(self, signature: str, mint: str) -> tuple[int, int]:
        """Exact (raw, decimals) this transaction delivered to the wallet for `mint`.

        Read from the confirmed transaction's own pre/post token balances,
        which arrive atomically with the transaction record - unlike a separate
        balance lookup, which can lag the ledger by seconds.
        """
        assert self._keypair is not None
        try:
            sig = Signature.from_string(signature)
        except Exception:  # noqa: BLE001
            return 0, 0
        owner = str(self._keypair.pubkey())
        for _attempt in range(config.TX_LOOKUP_ATTEMPTS):
            try:
                resp = await self._rpc.get_transaction(sig, encoding="jsonParsed", max_supported_transaction_version=0)
            except Exception:  # noqa: BLE001
                resp = None
            if resp is not None and resp.value is not None:
                meta = resp.value.transaction.meta
                pre_by_index = {b.account_index: b for b in (meta.pre_token_balances or [])}
                for post in meta.post_token_balances or []:
                    if str(post.mint) != mint or str(post.owner or "") != owner:
                        continue
                    post_amount = int(post.ui_token_amount.amount)
                    pre = pre_by_index.get(post.account_index)
                    pre_amount = int(pre.ui_token_amount.amount) if pre else 0
                    return max(post_amount - pre_amount, 0), int(post.ui_token_amount.decimals)
                return 0, 0
            await asyncio.sleep(config.TX_LOOKUP_INTERVAL_SECONDS)
        return 0, 0

    async def _wallet_delta_lamports(self, signature: str) -> Optional[int]:
        """Net lamports a confirmed transaction moved into (+) or out of (-) the wallet.

        Read from the balances the runtime recorded, so it is what the wallet
        actually got - proceeds net of fees.
        """
        assert self._keypair is not None
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getTransaction",
            "params": [signature, {"encoding": "json", "commitment": "confirmed", "maxSupportedTransactionVersion": 0}],
        }
        wallet = str(self._keypair.pubkey())
        for _attempt in range(config.TX_LOOKUP_ATTEMPTS):
            try:
                async with self._http.post(self._settings.http_rpc_url, json=payload, timeout=self._timeout) as resp:
                    body = await resp.json(content_type=None)
                result = body.get("result")
                if result is not None:
                    meta = result["meta"]
                    index = result["transaction"]["message"]["accountKeys"].index(wallet)
                    return int(meta["postBalances"][index]) - int(meta["preBalances"][index])
            except (KeyError, ValueError, IndexError, TypeError):
                return None
            except Exception as exc:  # noqa: BLE001
                _log.debug("getTransaction %s failed: %r", signature[:16], exc)
            await asyncio.sleep(config.TX_LOOKUP_INTERVAL_SECONDS)
        return None

    # ---------------------------------------------------------------- trades
    async def buy(
        self,
        mint: str,
        amount_sol: float,
        slippage_bps: int,
        paper: bool,
        wait_for_route: float = 0.0,
        started_at: Optional[float] = None,
    ) -> TradeResult:
        """Spend amount_sol on `mint`.

        wait_for_route keeps asking Jupiter for that long when the coin isn't
        routable yet - which, for a coin minted a second ago, it usually isn't.
        """
        started_at = started_at if started_at is not None else time.monotonic()
        amount_lamports = int(amount_sol * LAMPORTS_PER_SOL)
        # A paper fill needs the mint's decimals, which a live fill reads from
        # its own transaction. Looked up alongside the quote, not after it.
        decimals_task = asyncio.create_task(self.get_decimals(mint)) if paper else None

        quote, error = await self._quote(config.SOL_MINT, mint, amount_lamports, slippage_bps, wait_for_route)
        if quote is None:
            if decimals_task is not None:
                decimals_task.cancel()
            return TradeResult(ok=False, paper=paper, error=f"no route: {error}")
        quoted_out = int(quote.get("outAmount") or 0)

        if decimals_task is not None:
            return await self._paper_buy(amount_sol, quote, quoted_out, started_at, decimals_task)

        if self._keypair is None:
            return TradeResult(ok=False, paper=False, error="no wallet configured - paper mode only")

        tx, error = await self._build_signed(quote)
        if tx is None:
            return TradeResult(ok=False, paper=False, error=error)
        signature = await self._send(tx)
        if signature is None:
            return TradeResult(ok=False, paper=False, error="send failed - check your RPC")
        confirmed, error = await self._confirm(signature)
        elapsed_ms = (time.monotonic() - started_at) * 1000
        if not confirmed:
            return TradeResult(ok=False, paper=False, error=error, signature=signature, elapsed_ms=elapsed_ms)

        received, decimals = await self._received_tokens(signature, mint)
        if received <= 0:
            return TradeResult(
                ok=False,
                paper=False,
                signature=signature,
                elapsed_ms=elapsed_ms,
                error="confirmed, but the transaction shows no tokens received - check your wallet",
            )
        return TradeResult(
            ok=True,
            paper=False,
            signature=signature,
            tokens_raw=received,
            decimals=decimals,
            sol_amount=amount_sol,
            elapsed_ms=elapsed_ms,
        )

    async def _paper_buy(
        self, amount_sol: float, quote: dict, quoted_out: int, started_at: float, decimals_task: asyncio.Task
    ) -> TradeResult:
        note = "priced from Jupiter's live quote - no wallet configured, so nothing was simulated"
        if self._keypair is not None:
            balance = await self.get_sol_balance()
            if balance < amount_sol + config.FEE_HEADROOM_SOL:
                note = (
                    f"priced from Jupiter's live quote - wallet holds {balance:.4f} SOL, "
                    "too little to simulate the real transaction"
                )
            else:
                ok, error = await self._simulate_buy(quote)
                if not ok:
                    decimals_task.cancel()
                    return TradeResult(ok=False, paper=True, error=f"simulated buy failed: {error}")
                note = "real transaction built, signed and simulated - it would have been accepted"
        decimals = await decimals_task
        return TradeResult(
            ok=True,
            paper=True,
            tokens_raw=quoted_out,
            decimals=decimals,
            sol_amount=amount_sol,
            elapsed_ms=(time.monotonic() - started_at) * 1000,
            note=note,
        )

    async def _simulate_buy(self, quote: dict) -> tuple[bool, Optional[str]]:
        tx, error = await self._build_signed(quote)
        if tx is None:
            return False, error
        ok, error = await self._simulate(tx)
        if not ok and error and any(marker in error for marker in _LAG_ERRORS):
            await asyncio.sleep(1.5)
            tx, build_error = await self._build_signed(quote)
            if tx is None:
                return False, build_error
            ok, error = await self._simulate(tx)
        return ok, error

    async def sell(self, mint: str, amount_raw: int, slippage_bps: int, paper: bool) -> TradeResult:
        """Sell amount_raw of `mint` back to SOL."""
        started_at = time.monotonic()
        if amount_raw <= 0:
            return TradeResult(ok=False, paper=paper, error="nothing to sell")

        quote, error = await self._quote(mint, config.SOL_MINT, amount_raw, slippage_bps, wait_seconds=0.0)
        if quote is None:
            return TradeResult(ok=False, paper=paper, error=f"no route: {error}")
        quoted_sol = int(quote.get("outAmount") or 0) / LAMPORTS_PER_SOL

        if paper:
            return TradeResult(
                ok=True,
                paper=True,
                tokens_raw=amount_raw,
                sol_amount=quoted_sol,
                elapsed_ms=(time.monotonic() - started_at) * 1000,
            )

        if self._keypair is None:
            return TradeResult(ok=False, paper=False, error="no wallet configured - paper mode only")

        tx, error = await self._build_signed(quote)
        if tx is None:
            return TradeResult(ok=False, paper=False, error=error)
        signature = await self._send(tx)
        if signature is None:
            return TradeResult(ok=False, paper=False, error="send failed - check your RPC")
        confirmed, error = await self._confirm(signature)
        elapsed_ms = (time.monotonic() - started_at) * 1000
        if not confirmed:
            return TradeResult(ok=False, paper=False, error=error, signature=signature, elapsed_ms=elapsed_ms)

        delta = await self._wallet_delta_lamports(signature)
        received = delta / LAMPORTS_PER_SOL if delta is not None and delta > 0 else quoted_sol
        return TradeResult(
            ok=True,
            paper=False,
            signature=signature,
            tokens_raw=amount_raw,
            sol_amount=received,
            elapsed_ms=elapsed_ms,
        )
