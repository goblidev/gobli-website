# Gobli Free

Both Gobli snipers in one free Telegram bot, so you can see exactly how they
work before you buy Gobli Pro:

- 🎯 **Manual** — paste a token's mint address into the chat and it's bought
  through Jupiter, with sell buttons and optional take-profit / stop-loss.
- 🤖 **Auto** — set one rule (a creator's wallet, or a ticker) and pump.fun
  launches are watched and bought for you.

Pick the mode from the `/start` menu. One mode is active at a time, and
positions from either mode stay visible and sellable in both.

Same self-hosted, non-custodial shape as Gobli Pro: it runs on your own
machine, your key never leaves it, and there is no server in the middle.

**It starts in paper mode, and works with no private key at all.** Paper
trades are priced from Jupiter's live quotes but nothing is ever sent, so you
can try both snipers end to end with zero SOL at risk.

---

## Gobli Free vs Gobli Pro

The free edition is a smaller build, not Gobli Pro with switches turned off.
It's a little slower and does a little less:

| | Gobli Free | Gobli Pro |
|---|---|---|
| Snipers | Manual or Auto, one at a time | Manual and Auto, side by side |
| Manual buy route | Jupiter | Straight at the pump.fun curve, Jupiter for the rest |
| Sending | Standard RPC `sendTransaction` | Helius Sender — staked connections and Jito routes |
| Priority fee | Fixed amount from `.env` | Fresh estimate plus compute tuning on every swap |
| Buy size | Your choice | Your choice (auto also has per-snipe caps) |
| Open positions | Up to 3 | No cap on manual; your own cap on auto |
| Sell buttons | 50% / 100% | 25 / 50 / 75 / 100% |
| Add to a position (DCA) | — | ✅ |
| Safety checks (manual) | DexScreener + Rugcheck | Adds GoPlus and holder concentration |
| TP / SL check interval | Every 5 s | Every 2 s |
| Launch detection (auto) | Confirmed launches, logs feed | Up to Helius' pre-execution feed |
| Auto buy path | Routed through Jupiter once it has indexed the coin | Builds the pump.fun buy itself — no aggregator round trip |
| Auto rules | 1 rule, 1 wallet or 1 exact ticker, fires once, lives ≤ 24 h | Unlimited rules, many wallets/tickers each, contains-matching |
| Ticker rule filters | Minimum SOL in curve | Adds max-SOL ceiling, creator-buy cap, instant ticker buys |
| Extras | — | bonk.fun alerts, PnL share cards, `/preflight` |
| Paper / dry-run mode | ✅ both modes | ✅ |
| Kill switch, daily cap, wallet ceiling | ✅ | ✅ |

Gobli Pro is a one-time purchase with full source — see
[gobli.io](https://gobli.io/products) or message
[@goblidev](https://t.me/goblidev). `/upgrade` in the bot shows the same list.
Moving to Pro keeps the same Helius key, Telegram bot and wallet.

---

## What you need

| Value | Where it comes from | Required? |
|---|---|---|
| `HELIUS_API_KEY` | [dashboard.helius.dev](https://dashboard.helius.dev) — the **free plan** is enough | Yes |
| `TELEGRAM_BOT_TOKEN` | @BotFather (below) | Yes |
| `TELEGRAM_CHAT_ID` | @userinfobot — your numeric user id | Yes |
| `PRIVATE_KEY` | A **dedicated** hot wallet, base58 | Only to trade real SOL |
| `JUPITER_API_KEY` | [portal.jup.ag](https://portal.jup.ag) — free tier | Optional |

Jupiter has announced it will retire keyless API access. The bot uses the
keyless endpoint when `JUPITER_API_KEY` is blank and the keyed one when it's
set, so adding a free key now means nothing breaks when that happens.

## Setup

### 1. Create the Telegram bot

1. Message **@BotFather**, send `/newbot`.
2. **Give it a boring, unremarkable name and username.** Avoid "sniper",
   "solana", "trade", "pump" and similar — Telegram's automated filters have
   banned trading bots on the name alone. Something like "Ledger Notes" is the
   right idea.
3. BotFather replies with a token like `8123456789:AAH...` — that's
   `TELEGRAM_BOT_TOKEN`. Treat it as a password.
4. Message **@userinfobot**; it replies with your numeric id — that's
   `TELEGRAM_CHAT_ID`.
5. Open a chat with your new bot and press **Start**.

Optionally, send BotFather `/setcommands` and paste:

```
start - Menu and mode switch
manual - Manual mode: paste a mint to buy
auto - Auto mode: set or manage your rule
positions - Open positions
balance - Wallet balance
config - Settings and limits
setbuy - Set buy amount
paper - Paper trading
live - Trade real SOL
panic - Pause the rule and sell everything
upgrade - What Gobli Pro adds
help - All commands
```

### 2. Write your `.env`

**The easy way: open `setup.html`** in Chrome, Edge or Brave, fill in the
form, click **Save .env** and pick this folder. It checks every value the same
way the bot does on startup, shows which wallet a private key belongs to, and
never makes a network request (view its source to confirm). Leave the wallet
on **Paper only** to try the bot without a key. Firefox and Safari download
the file instead — rename it to exactly `.env` and move it here.

Or by hand: `cp .env.example .env` and fill it in.

### 3. Install and run

Python **3.10–3.13**.

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

On a Linux VPS, `bash vps/install.sh` then `bash vps/start.sh` does the same
and locks `.env` down. `vps/gobli-free.service` keeps it running unattended.

The bot validates every `.env` value and prints the full list of problems
before refusing to start, rather than running on a bad config. When it's up,
it messages you in Telegram.

---

## Using it

`/start` opens the menu. Pick a sniper:

**🎯 Manual.** Paste a mint address. The buy fires immediately while
DexScreener and Rugcheck run alongside it; their results show on the BOUGHT
message as context and warnings, never as a gate. Each position gets
**Sell 50% / Sell 100%**, **Take profit** and **Stop loss** buttons.

**🤖 Auto.** Choose what you know about the coin:

- **Creator wallet** — the first coin that wallet launches on pump.fun is
  bought as soon as Jupiter can route it — usually within a second of the
  launch being confirmed.
- **Ticker** — anyone can mint a coin with any ticker for a couple of cents,
  and people do it on purpose around an anticipated launch. So a ticker rule
  never buys at launch: it watches each exact match for 10 minutes and buys
  only once enough real SOL has gone into its bonding curve. Copycats almost
  never get there. Tickers that mix alphabets (a Cyrillic letter among Latin
  ones — the classic impersonation trick) are refused.

Then buy size, take profit / stop loss, and how long the rule lives (1 h,
6 h or 24 h — every rule expires). The launch feed only runs while a rule is
armed, so an idle bot costs no Helius streaming credits.

**Paper → live.** With a wallet in `.env`, `/live confirm` switches to real
SOL and `/paper` switches back. A restart always comes back in the mode
`.env` declares. In paper mode with a funded wallet, every buy is also built,
signed and run through Solana's simulator, so a paper buy proves the live
path works.

Commands: `/start`, `/manual`, `/auto`, `/rule`, `/positions`,
`/sell <mint>`, `/balance`, `/config`, `/setbuy <sol>`,
`/setslippage [auto] <bps>`, `/paper`, `/live confirm`, `/panic`, `/resume`,
`/upgrade`, `/cancel`, `/help`. Only the chat id in `TELEGRAM_CHAT_ID` gets a
reply — every other chat is ignored silently.

---

## Safety and trust

A free bot that asks for a private key is exactly what a wallet drainer looks
like. So:

- **Only get it from gobli.io or @goblidev.** Scammers repackage free bots
  with key-stealers added. A copy from anywhere else is not this software.
- **You don't have to give it a key.** Paper mode needs none.
- **Full source, no obfuscation.** The key is read in `config.py` and used
  in `trader.py`, which signs with it — nowhere else. (`logger.py` also reads
  it, only to scrub it out of any log line.)
- **No phone-home.** No telemetry, no licence server, no update check.
- **Every host this bot talks to:**

  | Host | Why |
  |---|---|
  | `mainnet.helius-rpc.com` | Your RPC: balances, curve reads, sending, the launch feed |
  | `lite-api.jup.ag` or `api.jup.ag` | Jupiter: quotes, swap transactions, prices |
  | `api.rugcheck.xyz` | Rugcheck score on manual buys |
  | `api.dexscreener.com` | Name, market cap and liquidity on manual buys |
  | `api.coingecko.com` | SOL price, only if Jupiter's price is unavailable |
  | `api.telegram.org` | The bot itself |

  Solscan and DexScreener appear only as links in messages to you.
  `tests/test_network.py` fails if the code ever contains a host not on this
  list, if `setup.html` gains any way to make a request, or if the private key
  is read anywhere but `config.py`.

Guard rails, all checked immediately before every buy:

- **Kill switch** — `/panic` pauses the rule, drops every watch and sells
  every position; nothing buys again until `/resume`.
- **Daily cap** on live spend (`MAX_SOL_PER_DAY`), which survives a restart.
- **Wallet ceiling** — refuses to start if the wallet holds more than
  `HOT_WALLET_MAX_BALANCE_SOL`, which also catches the wrong key in `.env`.
- The auto mode **never buys the same coin twice**.
- Fee headroom — a buy that would leave too little SOL to sell with is refused.

---

## Limits of this version

1. **Positions are in memory.** A restart stops tracking them and their
   take-profit / stop-loss; the tokens stay in your wallet. The mode, the auto
   rule, buy size and the daily spend do persist.
2. **A brand-new coin needs Jupiter to index it** before it can be bought.
   That's usually under a second after the launch is confirmed; the auto mode
   keeps trying for 15 seconds.
3. **Ticker rules need a SOL-paired coin**, since the threshold is SOL in the
   curve. A good share of pump.fun launches are now quoted in other tokens;
   ticker rules skip those. Creator rules buy either kind.
4. **Paper fills are Jupiter's quote**, not a landed trade. Real fills can be
   worse, especially on a coin minted seconds ago.
5. **Safety checks are informational** and cover the basics only.

## Risk

Trading fresh Solana tokens loses money often, and an auto-sniper loses it
without asking. Most new coins are rugs or jokes, transactions can fail after
paying the fee, and liquidity can vanish faster than an exit can fire. Fund
the hot wallet only with what you can afford to lose entirely.

## Tests

```bash
python tests/test_core.py            # decoding, rules, risk, config, state
python tests/test_telegram_flow.py   # every menu and command, fake Telegram
python tests/test_network.py         # hosts and key handling
```

Or `pytest tests/`. None of them need network access.

## Layout

| File | Responsibility |
|---|---|
| `main.py` | Entry point, wiring, task lifecycle |
| `telegram_bot.py` | Menu, mode switch, rule builder, every command |
| `auto.py` | Launch → rule → watch → buy |
| `positions.py` | Open positions, sells, take-profit / stop-loss |
| `trader.py` | Quote, build, sign, simulate, send, confirm |
| `jupiter.py` | Jupiter API client and SOL price |
| `feed.py` | pump.fun launch feed |
| `pumpfun.py` | Launch-event and bonding-curve decoding, tickers |
| `rules.py` | The auto rule: model, validation, matching |
| `risk.py` | Checks before every buy |
| `state.py` | What survives a restart |
| `safety.py` | DexScreener and Rugcheck |
| `config.py` | `.env` loading and validation, free-edition limits |
| `logger.py` | Logging with secret redaction |
| `setup.html` | Offline form that writes your `.env` |
| `vps/` | Linux install script and systemd service |
| `LICENSE` | Licence terms — read Section 4 before funding anything |
