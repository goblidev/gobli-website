"""
The auto mode: launches in, snipes out.

    launch feed -> match the rule -> CREATOR: buy as soon as Jupiter can route it
                                  -> TICKER:  watch the curve, buy once enough
                                              real SOL has gone in

The feed only runs while the rule is armed and the bot is in auto mode, so an
idle bot costs no streaming credits. supervise() starts and stops it as the
rule is armed, paused, fires or expires, and as the mode changes.

How this differs from Gobli Pro, which is where its speed comes
from: that bot reads launches at an earlier stage of the transaction
lifecycle, builds the pump.fun buy itself from data already in the create
transaction (no aggregator round trip, no RPC read on the hot path), and
sends through Helius Sender. Gobli Free reads confirmed launches, routes the
buy through Jupiter once Jupiter has indexed the coin, and sends through the
standard RPC.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Optional

import config
import rules
from feed import LaunchFeed
from logger import get_logger
from positions import SOURCE_AUTO, Position, PositionBook
from pumpfun import Launch
from risk import RiskGate
from state import MODE_AUTO, Store
from trader import Trader

_log = get_logger(__name__)


@dataclass
class Watch:
    launch: Launch
    deadline: float
    last_sol_in_curve: float = 0.0


@dataclass
class AutoStats:
    matches: int = 0
    buys_attempted: int = 0
    buys_ok: int = 0
    buys_failed: int = 0
    last_detect_to_fill_ms: Optional[float] = None
    started_at: float = field(default_factory=time.time)


class AutoSniper:
    def __init__(
        self,
        settings,
        store: Store,
        feed: LaunchFeed,
        trader: Trader,
        book: PositionBook,
        risk: RiskGate,
        sol_price,
        ui,
    ) -> None:
        self._settings = settings
        self._store = store
        self._feed = feed
        self._trader = trader
        self._book = book
        self._risk = risk
        self._sol_price = sol_price
        self._ui = ui
        self.watching: dict[str, Watch] = {}
        self.stats = AutoStats()
        self._lock = asyncio.Lock()
        self._tasks: set[asyncio.Task] = set()
        self._was_armed = False
        self._announced_refusal: Optional[str] = None

    @property
    def feed(self) -> LaunchFeed:
        return self._feed

    @property
    def armed(self) -> bool:
        rule = self._store.rule
        return (
            self._store.mode == MODE_AUTO
            and rule is not None
            and rule.active
            and not self._store.killed
        )

    def _spawn(self, coro) -> None:
        task = asyncio.create_task(coro)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    # ------------------------------------------------------------ lifecycle
    async def supervise(self) -> None:
        """Keep the feed running exactly while there is something to snipe."""
        while True:
            try:
                await self.sync()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                _log.exception("Auto supervisor pass failed")
            await asyncio.sleep(2.0)

    async def sync(self) -> None:
        armed = self.armed
        if armed and not self._feed.running:
            self._feed.start()
        elif not armed and self._feed.running:
            await self._feed.stop()
            self.watching.clear()

        reason = self._feed.unavailable_reason
        if reason and reason != self._announced_refusal:
            self._announced_refusal = reason
            await self._ui.notify(
                f"⛔ The RPC refused the launch feed: {_esc(reason)}\n"
                "Auto mode can't see launches until this is fixed. Check HELIUS_API_KEY - I'll retry in 5 minutes."
            )
        elif not reason:
            self._announced_refusal = None

        if self._was_armed and not armed:
            rule = self._store.rule
            if rule is not None and rule.expired and not rule.exhausted and self._store.mode == MODE_AUTO:
                await self._ui.notify("⌛ Your auto rule expired without a match. /auto to set a new one.")
        self._was_armed = armed

    async def consume(self) -> None:
        async for launch in self._feed.events():
            try:
                await self._handle(launch)
            except Exception:  # noqa: BLE001
                _log.exception("Error handling launch %s", launch.signature[:16])

    async def _handle(self, launch: Launch) -> None:
        if not self.armed:
            return
        rule = self._store.rule
        reason = rules.match(rule, launch)
        if reason is None:
            return
        self.stats.matches += 1

        if rule.kind == rules.KIND_CREATOR:
            self._spawn(self._buy(launch, rule, reason, instant=True))
            return

        if launch.mint in self.watching:
            return
        if len(self.watching) >= config.FREE_MAX_WATCHES:
            _log.info("Watch list full - ignoring %s", launch.mint)
            return
        self.watching[launch.mint] = Watch(
            launch=launch, deadline=time.time() + config.FREE_WATCH_WINDOW_SECONDS
        )
        await self._ui.notify(
            f"👀 <b>Watching</b> {_esc(launch.symbol)} ({_esc(launch.name)})\n"
            f"Buying once {rule.min_sol_in_curve:g} SOL is in its curve, "
            f"within {config.FREE_WATCH_WINDOW_SECONDS / 60:.0f} min.\n"
            f"<code>{launch.mint}</code>"
        )

    # ---------------------------------------------------------------- watch
    async def watch_loop(self) -> None:
        while True:
            await asyncio.sleep(config.WATCH_POLL_SECONDS)
            for mint, watch in list(self.watching.items()):
                try:
                    await self._check_watch(mint, watch)
                except asyncio.CancelledError:
                    raise
                except Exception:  # noqa: BLE001
                    _log.exception("Watch check failed for %s", mint[:8])

    async def _check_watch(self, mint: str, watch: Watch) -> None:
        rule = self._store.rule
        if not self.armed or rule is None:
            self.watching.pop(mint, None)
            return
        symbol = _esc(watch.launch.symbol)

        if time.time() > watch.deadline:
            self.watching.pop(mint, None)
            await self._ui.notify(
                f"⏳ Stopped watching {symbol} - it reached {watch.last_sol_in_curve:.2f} of "
                f"{rule.min_sol_in_curve:g} SOL in {config.FREE_WATCH_WINDOW_SECONDS / 60:.0f} min."
            )
            return

        curve = await self._trader.read_curve(mint)
        if curve is None:
            return
        watch.last_sol_in_curve = curve.sol_in_curve

        if curve.complete:
            self.watching.pop(mint, None)
            await self._ui.notify(f"🎓 {symbol} finished its bonding curve before the threshold - not buying.")
            return
        if curve.sol_in_curve < (rule.min_sol_in_curve or 0):
            return

        self.watching.pop(mint, None)
        self._spawn(self._buy(watch.launch, rule, f"{curve.sol_in_curve:.2f} SOL in curve", instant=False))

    # ------------------------------------------------------------------ buy
    async def _buy(self, launch: Launch, rule: rules.Rule, reason: str, instant: bool) -> None:
        async with self._lock:
            # Re-checked under the lock: the rule fires once, and a second
            # match can arrive while the first buy is waiting for a route.
            if not self.armed or self._store.rule is not rule:
                return

            runtime = self._settings.runtime
            paper = runtime.dry_run
            amount = rule.buy_amount_sol or runtime.buy_amount_sol
            balance = 0.0 if paper else await self._trader.get_sol_balance()
            refusal = self._risk.check(
                launch.mint,
                amount,
                open_positions=len(self._book.positions),
                holding_mint=self._book.holds(launch.mint),
                wallet_balance_sol=balance,
                paper=paper,
                auto=True,
            )
            header = f"{_esc(launch.symbol)} · {_esc(launch.name)}"
            if refusal is not None:
                await self._ui.notify(f"🚫 Not buying {header}: {refusal}")
                return

            self.stats.buys_attempted += 1
            result = await self._trader.buy(
                launch.mint,
                amount,
                runtime.auto_slippage_bps,
                paper=paper,
                wait_for_route=config.FREE_ROUTE_WAIT_SECONDS if instant else 5.0,
                # A creator snipe is timed from the moment the launch arrived; a
                # watched coin from the moment it crossed its threshold.
                started_at=launch.received_at if instant else time.monotonic(),
            )

            if not result.ok:
                self.stats.buys_failed += 1
                tag = "🧪 Paper buy" if paper else "Buy"
                tx = f"\n<a href=\"https://solscan.io/tx/{result.signature}\">tx</a>" if result.signature else ""
                await self._ui.notify(
                    f"❌ <b>{tag} failed</b> {header}\n{_esc(str(result.error))}{tx}\n"
                    f"<code>{launch.mint}</code>\nThe rule stays armed."
                )
                return

            self.stats.buys_ok += 1
            self.stats.last_detect_to_fill_ms = result.elapsed_ms
            self._store.record_auto_buy(launch.mint)
            if not paper:
                self._store.record_live_spend(amount)

            tokens = result.tokens_raw / (10**result.decimals) if result.decimals else float(result.tokens_raw)
            sol_usd = self._sol_price.get()
            entry_price_usd = (amount * sol_usd / tokens) if tokens and sol_usd else 0.0
            timing = ""
            if result.elapsed_ms:
                start = "launch" if instant else "threshold"
                timing = f"{start} → {'priced' if paper else 'confirmed'} in {result.elapsed_ms / 1000:.1f}s"
            details = [f"🤖 Auto · {reason}"]
            if timing:
                details.append(timing)
            if result.note:
                details.append(f"<i>{_esc(result.note)}</i>")

            position = Position(
                mint=launch.mint,
                name=launch.name or "Unknown",
                symbol=launch.symbol or launch.mint[:4],
                decimals=result.decimals,
                entry_tokens_raw=result.tokens_raw,
                tokens_raw=result.tokens_raw,
                sol_spent=amount,
                entry_price_usd=entry_price_usd,
                paper=paper,
                source=SOURCE_AUTO,
                take_profit_pct=rule.take_profit_pct,
                stop_loss_pct=rule.stop_loss_pct,
                buy_signature=result.signature,
                details=details,
            )
            self._book.open(position)
            await self._ui.show_new_position(position)
            await self._ui.notify("✔️ Your auto rule fired - each rule buys once. /auto to set the next one.")

    async def drop_watches(self) -> int:
        count = len(self.watching)
        self.watching.clear()
        return count


def _esc(text: str) -> str:
    """Minimal HTML escaping. Coin names are chosen by whoever launched them."""
    return (text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
