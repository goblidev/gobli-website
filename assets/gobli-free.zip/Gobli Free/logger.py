"""
Logging setup. Every module gets a logger via get_logger(), writing to both
the console and gobli_free.log.
"""

from __future__ import annotations

import logging
import os
import re
from logging.handlers import RotatingFileHandler
from pathlib import Path

from dotenv import load_dotenv

# Idempotent - config.py also calls this, but logger.py shouldn't depend on
# import order to have secrets available for the redaction filter below.
load_dotenv()

LOG_DIR = Path(__file__).resolve().parent


class _RedactSecretsFilter(logging.Filter):
    """Scrubs known secret values out of every log record before it's written.

    Defense-in-depth beyond capping the noisy HTTP loggers below: that closes
    the leaks we know about, but this catches the *value* of any secret
    wherever it appears - our own code, a dependency, or a future one.
    """

    def __init__(self) -> None:
        super().__init__()
        secrets: list[str] = []
        for name in ("TELEGRAM_BOT_TOKEN", "HELIUS_API_KEY", "JUPITER_API_KEY", "PRIVATE_KEY"):
            value = os.getenv(name, "").strip()
            if value:
                secrets.append(value)
        for url_var in ("HTTP_RPC_URL", "WS_RPC_URL"):
            match = re.search(r"api-key=([^&\s]+)", os.getenv(url_var, ""))
            if match:
                secrets.append(match.group(1))
        # Ignore anything trivially short - not worth the false-positive risk
        # of redacting short substrings that happen to appear elsewhere.
        self._secrets = [s for s in secrets if len(s) >= 8]

    def filter(self, record: logging.LogRecord) -> bool:
        if not self._secrets:
            return True
        message = record.getMessage()
        redacted = message
        for secret in self._secrets:
            redacted = redacted.replace(secret, "[REDACTED]")
        if redacted != message:
            record.msg = redacted
            record.args = ()
        return True


_redact_filter = _RedactSecretsFilter()
_console_handler = logging.StreamHandler()
_file_handler = RotatingFileHandler(
    LOG_DIR / "gobli_free.log",
    maxBytes=5 * 1024 * 1024,  # 5 MB per file
    backupCount=3,
    encoding="utf-8",
)
# Attached at the handler level (not the logger level) so it applies no
# matter which logger a record came from.
_console_handler.addFilter(_redact_filter)
_file_handler.addFilter(_redact_filter)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[_console_handler, _file_handler],
)

# basicConfig() configures the ROOT logger, which every library logger
# propagates to. The HTTP stacks in our dependency tree log full request URLs
# at INFO level, and those URLs carry secrets: python-telegram-bot's calls
# include the bot token in the path, solana-py's include the RPC api-key, and
# websockets logs the feed URL the same way. None of their INFO output is
# useful here, so they're capped at WARNING.
for _noisy_logger in ("httpx", "httpcore", "httpx2", "httpcore2", "websockets", "websockets.client"):
    logging.getLogger(_noisy_logger).setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
