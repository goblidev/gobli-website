"""
The auto mode's rule: what to buy, and when.

Gobli Free holds one rule at a time, of one of two kinds:

  CREATOR - one wallet address. Buys the first coin that wallet launches, as
  soon as Jupiter can route it. The launcher's identity is the signal, so
  there is nothing to wait for.

  TICKER - one ticker, matched exactly. Anyone can mint a coin with any
  ticker for a couple of cents, and people do so deliberately around an
  anticipated launch, so a ticker rule never buys at launch. It watches the
  match and buys only once real SOL has gone into its bonding curve - a
  threshold copycat coins almost never reach.

Every rule expires, and every rule fires once.

Gobli Pro adds: any number of rules, several wallets and tickers
per rule, "contains" matching, a max-SOL ceiling, a creator-buy cap, instant
ticker buys and bonk.fun detection.
"""

from __future__ import annotations

import time
from dataclasses import asdict, dataclass, field
from typing import Optional

import config
from pumpfun import Launch, is_mixed_script, normalize_ticker

KIND_CREATOR = "creator"
KIND_TICKER = "ticker"


@dataclass
class Rule:
    kind: str
    target: str
    expires_at: float
    min_sol_in_curve: Optional[float] = None
    buy_amount_sol: Optional[float] = None
    take_profit_pct: Optional[float] = None
    stop_loss_pct: Optional[float] = None
    enabled: bool = True
    buys_done: int = 0
    created_at: float = field(default_factory=time.time)

    @property
    def expired(self) -> bool:
        return time.time() >= self.expires_at

    @property
    def exhausted(self) -> bool:
        return self.buys_done >= config.FREE_MAX_RULE_BUYS

    @property
    def active(self) -> bool:
        return self.enabled and not self.expired and not self.exhausted

    @property
    def status(self) -> str:
        if self.exhausted:
            return "✔️ fired"
        if self.expired:
            return "⌛ expired"
        if not self.enabled:
            return "⏸ paused"
        return "🟢 armed"

    def expires_in_text(self) -> str:
        remaining = self.expires_at - time.time()
        if remaining <= 0:
            return "expired"
        hours, seconds = divmod(int(remaining), 3600)
        return f"{hours}h {seconds // 60}m" if hours else f"{seconds // 60}m"

    def describe(self) -> str:
        if self.kind == KIND_CREATOR:
            head = f"🎯 creator {self.target[:4]}…{self.target[-4:]} · buys at launch"
        else:
            head = f"🔤 ticker {self.target} · buys at {self.min_sol_in_curve:g} SOL in curve"
        parts = [head]
        parts.append(f"buy {self.buy_amount_sol:g} SOL" if self.buy_amount_sol else "buy: default amount")
        if self.take_profit_pct is not None or self.stop_loss_pct is not None:
            tp = f"+{self.take_profit_pct:g}%" if self.take_profit_pct is not None else "-"
            sl = f"-{self.stop_loss_pct:g}%" if self.stop_loss_pct is not None else "-"
            parts.append(f"TP {tp} / SL {sl}")
        parts.append(f"expires in {self.expires_in_text()}")
        return " · ".join(parts)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Rule":
        return cls(
            kind=str(data["kind"]),
            target=str(data["target"]),
            expires_at=float(data["expires_at"]),
            min_sol_in_curve=data.get("min_sol_in_curve"),
            buy_amount_sol=data.get("buy_amount_sol"),
            take_profit_pct=data.get("take_profit_pct"),
            stop_loss_pct=data.get("stop_loss_pct"),
            enabled=bool(data.get("enabled", True)),
            buys_done=int(data.get("buys_done", 0)),
            created_at=float(data.get("created_at", time.time())),
        )


def validate_rule(rule: Rule) -> list[str]:
    """Problems that stop a rule from being armed. Empty means it's fine."""
    problems: list[str] = []
    if rule.kind not in (KIND_CREATOR, KIND_TICKER):
        problems.append(f"unknown rule kind {rule.kind!r}")
    if not rule.target:
        problems.append("a rule needs a creator wallet or a ticker")
    if rule.kind == KIND_TICKER:
        if rule.min_sol_in_curve is None or rule.min_sol_in_curve <= 0:
            problems.append("a ticker rule needs a minimum SOL-in-curve threshold")
        if is_mixed_script(rule.target):
            problems.append("that ticker mixes writing systems - the classic impersonation trick")
        if len(rule.target) > config.TICKER_MAX_LENGTH:
            problems.append(f"tickers are at most {config.TICKER_MAX_LENGTH} characters")
    if rule.expires_at <= time.time():
        problems.append("expiry is already in the past")
    if rule.buy_amount_sol is not None and not rule.buy_amount_sol > 0:
        problems.append("buy amount must be above 0 SOL")
    if rule.take_profit_pct is not None and rule.take_profit_pct <= 0:
        problems.append("take profit must be a positive percent")
    if rule.stop_loss_pct is not None and not 0 < rule.stop_loss_pct < 100:
        problems.append("stop loss must be between 0 and 100 percent")
    return problems


def match(rule: Optional[Rule], launch: Launch) -> Optional[str]:
    """Why this launch matches the rule, or None if it doesn't.

    Runs on data already in the create event - nothing here does I/O.
    """
    if rule is None or not rule.active:
        return None
    if rule.kind == KIND_CREATOR:
        # Jupiter routes through whatever the coin is quoted in, so a creator
        # rule buys SOL- and non-SOL-paired launches alike.
        if rule.target in (launch.creator, launch.user):
            return "creator wallet"
        return None
    # A ticker rule's threshold is SOL in the curve. A coin quoted in another
    # token has no SOL in its curve to measure.
    if not launch.is_sol_paired:
        return None
    if launch.normalized_symbol != normalize_ticker(rule.target):
        return None
    if is_mixed_script(launch.symbol):
        return None
    return "ticker"
