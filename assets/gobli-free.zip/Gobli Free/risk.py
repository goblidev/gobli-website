"""
The checks every buy passes immediately before it is sent - manual or auto,
paper or live.

They are checked at buy time rather than when a rule is armed, because what
they guard (today's spend, open positions, the wallet balance) moves under a
rule that was perfectly reasonable when you set it.

The kill switch is deliberately the crudest mechanism: one flag, checked
first, that stops every buy.
"""

from __future__ import annotations

from typing import Optional

import config
from state import Store


class RiskGate:
    def __init__(self, settings, store: Store) -> None:
        self._settings = settings
        self._store = store

    def check(
        self,
        mint: str,
        amount_sol: float,
        open_positions: int,
        holding_mint: bool,
        wallet_balance_sol: float,
        paper: bool,
        auto: bool,
    ) -> Optional[str]:
        """A reason to refuse this buy, or None if it may go ahead."""
        if self._store.killed:
            return "the kill switch is on - /resume releases it"

        if amount_sol > config.FREE_MAX_BUY_SOL:
            return f"{amount_sol:g} SOL is above the free edition's {config.FREE_MAX_BUY_SOL:g} SOL cap per buy"

        if holding_mint:
            return "you already hold this coin - sell it first (Gobli Pro can add to a position)"

        if open_positions >= config.FREE_MAX_OPEN_POSITIONS:
            return (
                f"{open_positions} positions are open, and the free edition holds at most "
                f"{config.FREE_MAX_OPEN_POSITIONS} - close one first"
            )

        if auto and mint in self._store.bought_mints:
            return "the auto mode already bought this coin once"

        if paper:
            return None

        spent = self._store.spent_today
        if spent + amount_sol > self._settings.max_sol_per_day:
            return f"daily cap reached ({spent:.4f} of {self._settings.max_sol_per_day:g} SOL spent today)"

        required = amount_sol + config.FEE_HEADROOM_SOL
        if wallet_balance_sol < required:
            return (
                f"wallet holds {wallet_balance_sol:.4f} SOL - this buy needs about {required:.4f} SOL "
                "including fees"
            )
        return None

    def startup_balance_check(self, wallet_balance_sol: float) -> Optional[str]:
        """Refuse to start if the hot wallet holds more than the ceiling.

        The wallet is meant to hold what you can afford to lose. A balance above
        the ceiling usually means the wrong key ended up in .env.
        """
        ceiling = self._settings.hot_wallet_max_balance_sol
        if ceiling > 0 and wallet_balance_sol > ceiling:
            return (
                f"the wallet holds {wallet_balance_sol:.4f} SOL, above HOT_WALLET_MAX_BALANCE_SOL "
                f"({ceiling:g} SOL). Use a dedicated hot wallet, move funds out, or raise the "
                "ceiling in .env if this is deliberate."
            )
        return None
