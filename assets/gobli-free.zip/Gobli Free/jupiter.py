"""
Jupiter client: quotes, swap transactions and prices.

Every trade Gobli Free makes - manual or automatic, buy or sell - is routed
through Jupiter's aggregator. That covers pump.fun coins on the bonding curve
and after they graduate, plus anything else Jupiter can route.

The client paces itself under Jupiter's free-tier limit rather than finding
it with a 429. A 429 that does slip through is retried once after a pause.
"""

from __future__ import annotations

import asyncio
import time
from collections import deque
from typing import Any, Optional

import aiohttp

import config
from logger import get_logger

_log = get_logger(__name__)


class _Pacer:
    """At most `per_minute` calls in any rolling 60-second window."""

    def __init__(self, per_minute: int) -> None:
        self._per_minute = per_minute
        self._stamps: deque[float] = deque()
        self._lock = asyncio.Lock()

    async def wait(self) -> None:
        async with self._lock:
            while True:
                now = time.monotonic()
                while self._stamps and now - self._stamps[0] >= 60.0:
                    self._stamps.popleft()
                if len(self._stamps) < self._per_minute:
                    self._stamps.append(now)
                    return
                await asyncio.sleep(60.0 - (now - self._stamps[0]) + 0.01)


class JupiterClient:
    def __init__(self, http: aiohttp.ClientSession, settings) -> None:
        self._http = http
        self._base = settings.jupiter_base_url
        self._headers = {"x-api-key": settings.jupiter_api_key} if settings.jupiter_api_key else {}
        self._timeout = aiohttp.ClientTimeout(total=config.HTTP_REQUEST_TIMEOUT_SECONDS)
        self._pacer = _Pacer(config.JUPITER_REQUESTS_PER_MINUTE)

    @property
    def keyed(self) -> bool:
        return bool(self._headers)

    async def _request(self, method: str, path: str, **kwargs) -> tuple[Optional[int], Any]:
        url = self._base + path
        for attempt in range(2):
            await self._pacer.wait()
            try:
                async with self._http.request(
                    method, url, headers=self._headers, timeout=self._timeout, **kwargs
                ) as resp:
                    status = resp.status
                    try:
                        body = await resp.json(content_type=None)
                    except Exception:  # noqa: BLE001
                        body = {"error": (await resp.text())[:300]}
            except Exception as exc:  # noqa: BLE001
                _log.warning("Jupiter %s %s failed: %r", method, path, exc)
                return None, {"error": repr(exc)}
            if status == 429 and attempt == 0:
                _log.warning("Jupiter rate limit hit on %s - pausing", path)
                await asyncio.sleep(2.0)
                continue
            return status, body
        return status, body

    # ------------------------------------------------------------------ swap
    async def quote(
        self, input_mint: str, output_mint: str, amount_raw: int, slippage_bps: int
    ) -> tuple[Optional[dict], Optional[str]]:
        """Best route for the swap. Returns (quote, None) or (None, reason)."""
        params = {
            "inputMint": input_mint,
            "outputMint": output_mint,
            "amount": str(amount_raw),
            "slippageBps": str(slippage_bps),
            "restrictIntermediateTokens": "true",
        }
        status, body = await self._request("GET", config.JUPITER_QUOTE_PATH, params=params)
        if status == 200 and isinstance(body, dict) and body.get("routePlan"):
            return body, None
        reason = f"quote failed (HTTP {status})"
        if isinstance(body, dict):
            parts = [str(body[k]) for k in ("error", "errorCode", "message") if body.get(k)]
            reason = " / ".join(parts) or reason
        return None, reason[:200]

    async def swap_transaction(
        self, quote: dict, user_public_key: str, priority_fee_lamports: int
    ) -> tuple[Optional[str], Optional[str]]:
        """Jupiter-built, unsigned swap transaction (base64), ready to sign.

        The priority fee is a fixed amount from .env. Gobli Pro
        estimates a fresh fee and tunes the compute budget before every swap.
        """
        body = {
            "quoteResponse": quote,
            "userPublicKey": user_public_key,
            "wrapAndUnwrapSol": True,
            "dynamicComputeUnitLimit": True,
            "prioritizationFeeLamports": priority_fee_lamports,
        }
        status, data = await self._request("POST", config.JUPITER_SWAP_PATH, json=body)
        if status == 200 and isinstance(data, dict) and data.get("swapTransaction"):
            return data["swapTransaction"], None
        reason = None
        if isinstance(data, dict):
            reason = data.get("error") or data.get("errorCode") or data.get("message")
        return None, str(reason or f"swap build failed (HTTP {status})")[:200]

    # ----------------------------------------------------------------- price
    async def prices_usd(self, mints: list[str]) -> dict[str, float]:
        """USD prices for up to 50 mints in one call. Missing mints are omitted."""
        unique = list(dict.fromkeys(m for m in mints if m))[:50]
        if not unique:
            return {}
        status, body = await self._request(
            "GET", config.JUPITER_PRICE_PATH, params={"ids": ",".join(unique)}
        )
        if status != 200 or not isinstance(body, dict):
            return {}
        prices: dict[str, float] = {}
        for mint in unique:
            entry = body.get(mint)
            if isinstance(entry, dict) and entry.get("usdPrice") is not None:
                try:
                    prices[mint] = float(entry["usdPrice"])
                except (TypeError, ValueError):
                    continue
        return prices


class SolPriceCache:
    """Background-refreshed SOL/USD price, so trades never wait on it."""

    def __init__(self, jupiter: JupiterClient, http: aiohttp.ClientSession) -> None:
        self._jupiter = jupiter
        self._http = http
        self._price = 0.0

    def get(self) -> float:
        return self._price

    async def refresh_once(self) -> None:
        prices = await self._jupiter.prices_usd([config.SOL_MINT])
        price = prices.get(config.SOL_MINT)
        if price is None:
            price = await self._coingecko()
        if price:
            self._price = price

    async def _coingecko(self) -> Optional[float]:
        try:
            async with self._http.get(
                config.COINGECKO_SOL_PRICE_URL,
                params={"ids": "solana", "vs_currencies": "usd"},
                timeout=aiohttp.ClientTimeout(total=config.HTTP_REQUEST_TIMEOUT_SECONDS),
            ) as resp:
                if resp.status != 200:
                    return None
                data = await resp.json()
            value = (data.get("solana") or {}).get("usd")
            return float(value) if value is not None else None
        except Exception:  # noqa: BLE001
            return None

    async def refresh_forever(self) -> None:
        while True:
            try:
                await self.refresh_once()
            except Exception:  # noqa: BLE001
                _log.warning("SOL price refresh failed, keeping %.2f", self._price)
            await asyncio.sleep(config.SOL_PRICE_REFRESH_SECONDS)
