"""
Central configuration. Every secret and every tunable trading parameter is
read from the environment (.env) - nothing user-specific is hardcoded here.

Three kinds of constants live in this file:

  - Free-edition limits (FREE_*). These are what separate Gobli Free from Gobli
    Pro, and they are kept together in one block so they are easy to find
    and easy to read.
  - Protocol constants (program IDs, discriminators, well-known mints). Not
    secrets and not amounts - fixed addresses defined by Solana and pump.fun.
  - Public API endpoints and fixed pipeline timings.
"""

from __future__ import annotations

import os
import stat
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import base58
from dotenv import load_dotenv
from solders.keypair import Keypair

load_dotenv()


class ConfigError(Exception):
    """Raised when .env is missing or contains invalid values."""


# --------------------------------------------------------------------------
# Free-edition limits
# --------------------------------------------------------------------------
# Positions open at once, across both modes.
FREE_MAX_OPEN_POSITIONS = 3
# Sell buttons on a position. Gobli Pro offers 25/50/75/100.
FREE_SELL_PERCENTS = (50, 100)
# How often take-profit / stop-loss levels are checked.
FREE_PRICE_CHECK_SECONDS = 5.0
# The auto mode holds one rule, with one creator wallet or one exact ticker,
# and each rule fires once.
FREE_MAX_RULE_BUYS = 1
# How long a ticker rule watches a matched launch for its SOL threshold.
FREE_WATCH_WINDOW_SECONDS = 600.0
# At most this many launches are watched at once.
FREE_MAX_WATCHES = 10
# Rule lifetimes on offer. Every rule expires.
FREE_RULE_EXPIRY_CHOICES = {"1h": 3_600, "6h": 21_600, "24h": 86_400}
# A creator snipe buys through Jupiter, which needs a moment to index a coin
# that was minted a second ago. This is how long it keeps asking.
FREE_ROUTE_WAIT_SECONDS = 15.0
# Launch detection reads pump.fun's create events at "confirmed" commitment:
# the create has been voted on by the cluster, so a launch that later drops
# off a fork is never acted on. Gobli Pro reads earlier stages.
FEED_COMMITMENT = "confirmed"

# Informational thresholds for the warning line on a manual buy. They never
# block a purchase.
WARN_MIN_LIQUIDITY_USD = 5_000.0
WARN_MIN_RUGCHECK_SCORE = 60.0

UPGRADE_URL = "https://gobli.io/products"
CONTACT_URL = "https://t.me/goblidev"

# --------------------------------------------------------------------------
# Solana / SPL protocol constants
# --------------------------------------------------------------------------
SOL_MINT = "So11111111111111111111111111111111111111112"
TOKEN_PROGRAM_ID = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
# Token-2022 is a separate program, not a newer version of the one above.
# Every pump.fun create_v2 coin is a Token-2022 mint.
TOKEN_2022_PROGRAM_ID = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
ASSOCIATED_TOKEN_PROGRAM_ID = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"

# --------------------------------------------------------------------------
# pump.fun protocol constants
# --------------------------------------------------------------------------
PUMP_PROGRAM_ID = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"
# Appears in pump.fun's create and create_v2 instructions and in no other
# instruction, so a log subscription filtered on it carries coin creations
# and nothing else.
PUMP_MINT_AUTHORITY = "TSLvdd1pWpHVjahSpsvCXUbgwsL3JAcvokwaKt1eokM"
# Anchor CreateEvent, emitted into the transaction logs on every launch.
CREATE_EVENT_DISCRIMINATOR = bytes([27, 114, 169, 77, 222, 235, 99, 118])
TICKER_MAX_LENGTH = 13

# --------------------------------------------------------------------------
# Endpoints
# --------------------------------------------------------------------------
HTTP_RPC_TEMPLATE = "https://mainnet.helius-rpc.com/?api-key={key}"
WS_RPC_TEMPLATE = "wss://mainnet.helius-rpc.com/?api-key={key}"

# Jupiter serves the same paths on two hosts: lite-api needs no key, api.jup.ag
# takes one from portal.jup.ag (free tier available). Jupiter has announced
# that keyless access will be retired, so setting JUPITER_API_KEY now means
# nothing changes for you when it is.
JUPITER_KEYLESS_BASE = "https://lite-api.jup.ag"
JUPITER_KEYED_BASE = "https://api.jup.ag"
JUPITER_QUOTE_PATH = "/swap/v1/quote"
JUPITER_SWAP_PATH = "/swap/v1/swap"
JUPITER_PRICE_PATH = "/price/v3"
# Jupiter's free tier is 60 requests a minute; the client paces itself under it.
JUPITER_REQUESTS_PER_MINUTE = 55

RUGCHECK_API_BASE = "https://api.rugcheck.xyz/v1"
DEXSCREENER_TOKENS_URL = "https://api.dexscreener.com/latest/dex/tokens"
COINGECKO_SOL_PRICE_URL = "https://api.coingecko.com/api/v3/simple/price"

# --------------------------------------------------------------------------
# Fixed pipeline timings
# --------------------------------------------------------------------------
HTTP_CONNECTOR_LIMIT = 50
HTTP_REQUEST_TIMEOUT_SECONDS = 5.0
SAFETY_CHECK_BUDGET_SECONDS = 3.0
CONFIRM_TIMEOUT_SECONDS = 40.0
CONFIRM_POLL_INTERVAL_SECONDS = 0.4
ROUTE_RETRY_INTERVAL_SECONDS = 0.5
WATCH_POLL_SECONDS = 3.0
SOL_PRICE_REFRESH_SECONDS = 30.0
FEED_RECONNECT_BASE_DELAY_SECONDS = 1.0
FEED_RECONNECT_MAX_DELAY_SECONDS = 30.0
TELEGRAM_RECONNECT_BASE_DELAY_SECONDS = 1.0
TELEGRAM_RECONNECT_MAX_DELAY_SECONDS = 30.0
TX_LOOKUP_ATTEMPTS = 6
TX_LOOKUP_INTERVAL_SECONDS = 1.0
# Headroom kept back from every buy for network fees and the token account's
# rent, so a buy never leaves the wallet unable to pay for the sell.
FEE_HEADROOM_SOL = 0.01


def _check_env_file_permissions(errors: list[str]) -> None:
    """Refuse to start if .env is readable by anyone but its owner.

    POSIX only - Windows' permission model doesn't map onto the same mode
    bits, and the recommended deployment target is a Linux VPS.
    """
    if os.name != "posix":
        return
    env_path = Path(".env")
    if not env_path.exists():
        return
    mode = env_path.stat().st_mode
    if mode & (stat.S_IRWXG | stat.S_IRWXO):
        errors.append(
            f".env has permissions {oct(mode)[-3:]} - readable by other users on this machine. "
            "It can hold your wallet's private key. Fix it with: chmod 600 .env"
        )


def _decode_keypair(raw: str) -> tuple[Optional[Keypair], Optional[str]]:
    """Decode a base58 private key, or say exactly what is wrong with it.

    The length is checked before solders sees the bytes: on malformed input
    solders raises a Rust panic, which derives from BaseException rather than
    Exception and would otherwise escape as a traceback instead of a config
    error.
    """
    try:
        decoded = base58.b58decode(raw)
    except ValueError:
        return None, "it is not valid base58"
    if len(decoded) != 64:
        return None, (
            f"it decodes to {len(decoded)} bytes, not 64 - export the full private key, "
            "not the seed phrase or the public address"
        )
    try:
        return Keypair.from_bytes(decoded), None
    except BaseException as exc:  # noqa: BLE001 - see docstring
        if isinstance(exc, (KeyboardInterrupt, SystemExit)):
            raise
        return None, f"it is not a valid keypair ({exc})"


@dataclass
class RuntimeConfig:
    """Trading parameters changed from Telegram without a restart."""

    buy_amount_sol: float
    slippage_bps: int
    auto_slippage_bps: int
    priority_fee_lamports: int
    dry_run: bool

    @property
    def buy_amount_lamports(self) -> int:
        return int(self.buy_amount_sol * 1_000_000_000)


@dataclass(frozen=True)
class Settings:
    http_rpc_url: str
    ws_rpc_url: str
    jupiter_base_url: str
    jupiter_api_key: Optional[str]
    # None means no wallet: paper mode only.
    keypair: Optional[Keypair]

    runtime: RuntimeConfig

    max_sol_per_day: float
    hot_wallet_max_balance_sol: float

    telegram_bot_token: str
    telegram_chat_id_int: int

    state_path: Path = field(default=Path("gobli_free_state.json"))

    @property
    def has_wallet(self) -> bool:
        return self.keypair is not None


def load_settings() -> Settings:
    """Read, validate and type-cast every .env value.

    Raises ConfigError with a single message listing every problem found (not
    just the first) so the user can fix everything in one pass.
    """
    errors: list[str] = []

    _check_env_file_permissions(errors)

    api_key = os.getenv("HELIUS_API_KEY", "").strip()
    http_override = os.getenv("HTTP_RPC_URL", "").strip()
    ws_override = os.getenv("WS_RPC_URL", "").strip()
    if not api_key and not (http_override and ws_override):
        errors.append("HELIUS_API_KEY is not set (a free key from dashboard.helius.dev is enough)")

    def _endpoint(override: str, name: str, template: str, schemes: tuple[str, ...]) -> str:
        if override:
            if not override.startswith(schemes):
                errors.append(f"{name} must start with {' or '.join(schemes)} (or be left blank)")
            return override
        return template.format(key=api_key) if api_key else ""

    http_rpc_url = _endpoint(http_override, "HTTP_RPC_URL", HTTP_RPC_TEMPLATE, ("http://", "https://"))
    ws_rpc_url = _endpoint(ws_override, "WS_RPC_URL", WS_RPC_TEMPLATE, ("ws://", "wss://"))

    jupiter_api_key = os.getenv("JUPITER_API_KEY", "").strip() or None
    jupiter_base_url = JUPITER_KEYED_BASE if jupiter_api_key else JUPITER_KEYLESS_BASE

    private_key = os.getenv("PRIVATE_KEY", "").strip()
    keypair: Optional[Keypair] = None
    if private_key:
        keypair, problem = _decode_keypair(private_key)
        if problem:
            errors.append(f"PRIVATE_KEY is not usable: {problem}")

    def _float(name: str, default: str, lo: float | None = None, hi: float | None = None) -> float:
        raw = os.getenv(name, default).strip()
        try:
            value = float(raw)
        except ValueError:
            errors.append(f"{name}={raw!r} is not a valid number")
            return 0.0
        if lo is not None and value < lo:
            errors.append(f"{name}={value} must be >= {lo}")
        if hi is not None and value > hi:
            errors.append(f"{name}={value} must be <= {hi}")
        return value

    def _int(name: str, default: str, lo: int | None = None, hi: int | None = None) -> int:
        raw = os.getenv(name, default).strip()
        try:
            value = int(raw)
        except ValueError:
            errors.append(f"{name}={raw!r} is not a valid integer")
            return 0
        if lo is not None and value < lo:
            errors.append(f"{name}={value} must be >= {lo}")
        if hi is not None and value > hi:
            errors.append(f"{name}={value} must be <= {hi}")
        return value

    def _bool(name: str, default: str) -> bool:
        raw = os.getenv(name, default).strip().lower()
        if raw in ("1", "true", "yes", "on"):
            return True
        if raw in ("0", "false", "no", "off"):
            return False
        errors.append(f"{name}={raw!r} is not a valid boolean (use true/false)")
        return True

    buy_amount_sol = _float("BUY_AMOUNT_SOL", "0.02", lo=0.000001)
    slippage_bps = _int("SLIPPAGE_BPS", "500", lo=1, hi=10000)
    auto_slippage_bps = _int("AUTO_SLIPPAGE_BPS", "2500", lo=1, hi=10000)
    priority_fee_lamports = _int("PRIORITY_FEE_LAMPORTS", "300000", lo=0, hi=5_000_000)
    # Paper mode defaults ON, and is forced on when there is no wallet.
    dry_run = _bool("DRY_RUN", "true") or keypair is None

    max_sol_per_day = _float("MAX_SOL_PER_DAY", "0.5", lo=0.000001)
    hot_wallet_max_balance_sol = _float("HOT_WALLET_MAX_BALANCE_SOL", "1.0", lo=0.0)

    telegram_bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    telegram_chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    telegram_chat_id_int = 0
    if not telegram_bot_token:
        errors.append("TELEGRAM_BOT_TOKEN is not set")
    if not telegram_chat_id:
        errors.append("TELEGRAM_CHAT_ID is not set")
    else:
        try:
            telegram_chat_id_int = int(telegram_chat_id)
        except ValueError:
            errors.append(f"TELEGRAM_CHAT_ID={telegram_chat_id!r} is not a valid integer chat id")

    if errors:
        raise ConfigError(
            "Invalid configuration - fix the following in your .env file:\n"
            + "\n".join(f"  - {e}" for e in errors)
        )

    return Settings(
        http_rpc_url=http_rpc_url,
        ws_rpc_url=ws_rpc_url,
        jupiter_base_url=jupiter_base_url,
        jupiter_api_key=jupiter_api_key,
        keypair=keypair,
        runtime=RuntimeConfig(
            buy_amount_sol=buy_amount_sol,
            slippage_bps=slippage_bps,
            auto_slippage_bps=auto_slippage_bps,
            priority_fee_lamports=priority_fee_lamports,
            dry_run=dry_run,
        ),
        max_sol_per_day=max_sol_per_day,
        hot_wallet_max_balance_sol=hot_wallet_max_balance_sol,
        telegram_bot_token=telegram_bot_token,
        telegram_chat_id_int=telegram_chat_id_int,
    )
