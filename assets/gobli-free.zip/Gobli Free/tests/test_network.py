"""
What this bot can talk to, and where your private key goes.

A free bot that asks for a private key is exactly what a wallet drainer looks
like, so these checks make the answers mechanical rather than a promise:

  - every web address in the code is on the list published in README.md
  - setup.html contains nothing that can make a network request
  - PRIVATE_KEY is read in config.py and nowhere else (logger.py only reads
    it to scrub it out of log lines), and only trader.py signs anything

Run with `pytest tests/` or directly with `python tests/test_network.py`.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent

# Hosts the bot sends requests to. README.md "Every host this bot talks to"
# lists the same set, plus api.telegram.org, which python-telegram-bot calls.
CONTACTED_HOSTS = {
    "mainnet.helius-rpc.com",
    "lite-api.jup.ag",
    "api.jup.ag",
    "api.rugcheck.xyz",
    "api.dexscreener.com",
    "api.coingecko.com",
}
# Hosts that only ever appear as links in messages sent to you.
LINK_HOSTS = {"solscan.io", "dexscreener.com", "gobli.io", "t.me"}

URL_RE = re.compile(r"(?:https?|wss?)://([A-Za-z0-9.-]+)")


def _source_files() -> list[Path]:
    return [p for p in _ROOT.glob("*.py")]


def test_every_host_in_the_code_is_on_the_published_list():
    found: dict[str, set[str]] = {}
    for path in _source_files():
        for host in URL_RE.findall(path.read_text(encoding="utf-8")):
            found.setdefault(host, set()).add(path.name)
    unexpected = {h: sorted(f) for h, f in found.items() if h not in CONTACTED_HOSTS | LINK_HOSTS}
    assert not unexpected, f"hosts not on the published list: {unexpected}"
    missing = CONTACTED_HOSTS - set(found)
    assert not missing, f"listed but no longer used - update README and this test: {missing}"


def test_readme_publishes_the_same_list():
    readme = (_ROOT / "README.md").read_text(encoding="utf-8")
    for host in CONTACTED_HOSTS | {"api.telegram.org"}:
        assert host in readme, f"README.md does not list {host}"


def test_setup_page_cannot_make_requests():
    page = (_ROOT / "setup.html").read_text(encoding="utf-8")
    for marker in ("fetch(", "XMLHttpRequest", "WebSocket(", "sendBeacon(", "EventSource(", "import(",
                   "<script src", "<link", "<img", "<iframe", "@import", "url(http"):
        assert marker not in page, f"setup.html contains {marker!r}"


def test_private_key_is_read_in_one_place():
    readers = sorted(p.name for p in _source_files() if "PRIVATE_KEY" in p.read_text(encoding="utf-8"))
    assert readers == ["config.py", "logger.py"], readers
    logger_src = (_ROOT / "logger.py").read_text(encoding="utf-8")
    assert '"PRIVATE_KEY"' in logger_src and "REDACTED" in logger_src


def test_only_the_trader_signs():
    signers = sorted(p.name for p in _source_files() if "sign_message(" in p.read_text(encoding="utf-8"))
    assert signers == ["trader.py"], signers


def test_every_module_compiles_and_imports():
    """A syntax error in a file no other test touches would otherwise ship."""
    import importlib

    for path in _source_files():
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    sys.path.insert(0, str(_ROOT))
    for path in _source_files():
        importlib.import_module(path.stem)


def test_no_phone_home():
    """No telemetry, licence server or update check - the bot only talks to the hosts above."""
    for path in _source_files():
        text = path.read_text(encoding="utf-8").lower()
        for marker in ("telemetry", "analytics", "license_server", "licence server", "update_check"):
            assert marker not in text, f"{path.name} mentions {marker!r}"


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        try:
            fn()
            print(f"  PASS  {name}")
        except AssertionError as exc:
            failures += 1
            print(f"  FAIL  {name}\n        {exc}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            print(f"  ERROR {name}\n        {type(exc).__name__}: {exc}")
    print()
    print("FAILED" if failures else "All network and key-handling tests passed")
    sys.exit(1 if failures else 0)
