"""
End-to-end Telegram flows, against a fake Telegram server.

Drives real updates through the real handlers - menu, mode switching, the
auto rule builder, a manual paper buy, take-profit input, selling, limits and
the kill switch - with the trader, safety checks and launch feed stubbed out.
No network access is needed.

Run with `pytest tests/` or directly with `python tests/test_telegram_flow.py`.
"""

from __future__ import annotations

import asyncio
import itertools
import json
import sys
import tempfile
import time
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))

from solders.pubkey import Pubkey  # noqa: E402
from telegram import Update  # noqa: E402
from telegram.ext import ApplicationBuilder  # noqa: E402
from telegram.request import BaseRequest  # noqa: E402

import config  # noqa: E402
import telegram_bot  # noqa: E402
from auto import AutoSniper  # noqa: E402
from positions import PositionBook  # noqa: E402
from risk import RiskGate  # noqa: E402
from safety import SafetyReport  # noqa: E402
from state import MODE_AUTO, MODE_MANUAL, Store  # noqa: E402
from trader import TradeResult  # noqa: E402

OWNER = 424242
STRANGER = 999
MINT = str(Pubkey(bytes([21] * 32)))
MINT_2 = str(Pubkey(bytes([22] * 32)))
CREATOR = str(Pubkey(bytes([23] * 32)))


# ------------------------------------------------------------------ fakes
class FakeTelegram(BaseRequest):
    """Answers the Bot API calls the bot makes and records what it sent."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, dict]] = []
        self._ids = itertools.count(100)

    async def initialize(self) -> None:
        return None

    async def shutdown(self) -> None:
        return None

    async def do_request(self, url, method, request_data=None, read_timeout=None, write_timeout=None,
                         connect_timeout=None, pool_timeout=None):
        endpoint = url.rsplit("/", 1)[-1]
        params = {}
        if request_data is not None:
            for key, value in request_data.parameters.items():
                if isinstance(value, str) and value[:1] in "{[":
                    try:
                        value = json.loads(value)
                    except ValueError:
                        pass
                params[key] = value
        self.calls.append((endpoint, params))
        if endpoint == "getMe":
            result = {"id": 1, "is_bot": True, "first_name": "Ledger", "username": "ledger_notes_bot",
                      "can_join_groups": False, "can_read_all_group_messages": False,
                      "supports_inline_queries": False}
        elif endpoint in ("sendMessage", "editMessageText"):
            result = {"message_id": params.get("message_id") or next(self._ids), "date": int(time.time()),
                      "chat": {"id": OWNER, "type": "private"}, "text": params.get("text", "")}
        else:
            result = True
        return 200, json.dumps({"ok": True, "result": result}).encode()

    def texts(self) -> list[str]:
        return [p.get("text", "") for e, p in self.calls if e in ("sendMessage", "editMessageText")]

    def buttons(self) -> list[str]:
        out = []
        for e, p in self.calls:
            markup = p.get("reply_markup") or {}
            for row in markup.get("inline_keyboard", []):
                out.extend(b.get("callback_data") or b.get("url") for b in row)
        return out

    def clear(self) -> None:
        self.calls.clear()


class FakeTrader:
    pubkey = None

    def __init__(self) -> None:
        self.buys: list[tuple[str, float, bool]] = []
        self.sells: list[tuple[str, int, bool]] = []

    async def get_sol_balance(self):
        return 0.0

    async def get_token_balance(self, mint):
        return None

    async def read_curve(self, mint):
        return None

    async def buy(self, mint, amount_sol, slippage_bps, paper, wait_for_route=0.0, started_at=None):
        self.buys.append((mint, amount_sol, paper))
        return TradeResult(ok=True, paper=paper, tokens_raw=2_000_000_000_000, decimals=6,
                           sol_amount=amount_sol, elapsed_ms=180.0, note="priced from Jupiter's live quote")

    async def sell(self, mint, amount_raw, slippage_bps, paper):
        self.sells.append((mint, amount_raw, paper))
        return TradeResult(ok=True, paper=paper, tokens_raw=amount_raw, sol_amount=amount_raw / 1e14)


class FakeSafety:
    async def check(self, mint):
        return SafetyReport(name="Hello Coin", symbol="HELLO", market_cap_usd=5_000, liquidity_usd=3_000,
                            rugcheck_score=72)


class FakeJupiter:
    async def prices_usd(self, mints):
        return {m: 0.00001 for m in mints}


class FakeSolPrice:
    def get(self):
        return 100.0


class FakeFeed:
    def __init__(self) -> None:
        self.running = False
        self.connected = False
        self.launches_seen = 0
        self.unavailable_reason = None

    def start(self):
        self.running = True

    async def stop(self):
        self.running = False

    async def events(self):
        while True:
            await asyncio.sleep(3600)
            yield None


class Harness:
    def __init__(self) -> None:
        self.settings = config.Settings(
            http_rpc_url="https://rpc.invalid", ws_rpc_url="wss://rpc.invalid",
            jupiter_base_url=config.JUPITER_KEYLESS_BASE, jupiter_api_key=None, keypair=None,
            runtime=config.RuntimeConfig(buy_amount_sol=0.02, slippage_bps=500, auto_slippage_bps=2500,
                                         priority_fee_lamports=300000, dry_run=True),
            max_sol_per_day=0.5, hot_wallet_max_balance_sol=1.0,
            telegram_bot_token="123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
            telegram_chat_id_int=OWNER,
            state_path=Path(tempfile.mkdtemp()) / "state.json",
        )
        self.store = Store(self.settings.state_path)
        self.trader = FakeTrader()
        self.feed = FakeFeed()
        self.tg = FakeTelegram()
        risk = RiskGate(self.settings, self.store)
        self.ui = telegram_bot.TelegramUI(self.settings, self.store, self.trader, FakeSafety(), FakeSolPrice(), risk)
        original = telegram_bot.ApplicationBuilder
        telegram_bot.ApplicationBuilder = lambda: ApplicationBuilder().request(self.tg).get_updates_request(self.tg)
        try:
            self.app = self.ui.build()
        finally:
            telegram_bot.ApplicationBuilder = original
        self.book = PositionBook(self.settings, self.trader, FakeJupiter(), self.ui)
        self.auto = AutoSniper(self.settings, self.store, self.feed, self.trader, self.book, risk,
                               FakeSolPrice(), self.ui)
        self.ui.bind(self.book, self.auto)
        self._ids = itertools.count(1)

    async def start(self) -> None:
        await self.app.initialize()
        self.tg.clear()

    async def _process(self, payload: dict) -> None:
        await self.app.process_update(Update.de_json(payload, self.app.bot))
        while self.ui._tasks:  # noqa: SLF001 - wait for spawned buys and sells
            await asyncio.gather(*list(self.ui._tasks))  # noqa: SLF001

    async def send(self, text: str, chat: int = OWNER) -> None:
        message = {"message_id": next(self._ids), "date": int(time.time()),
                   "chat": {"id": chat, "type": "private"},
                   "from": {"id": chat, "is_bot": False, "first_name": "K"}, "text": text}
        if text.startswith("/"):
            message["entities"] = [{"type": "bot_command", "offset": 0, "length": len(text.split()[0])}]
        await self._process({"update_id": next(self._ids), "message": message})

    async def press(self, data: str, chat: int = OWNER) -> None:
        await self._process({"update_id": next(self._ids), "callback_query": {
            "id": str(next(self._ids)), "chat_instance": "c", "data": data,
            "from": {"id": chat, "is_bot": False, "first_name": "K"},
            "message": {"message_id": 1, "date": int(time.time()), "chat": {"id": chat, "type": "private"},
                        "text": "x"}}})

    def last(self) -> str:
        texts = self.tg.texts()
        return texts[-1] if texts else ""


def _run(coro_fn):
    async def go():
        harness = Harness()
        await harness.start()
        await coro_fn(harness)

    asyncio.run(go())


# ------------------------------------------------------------------ tests
def test_strangers_get_nothing():
    async def scenario(h: Harness):
        await h.send("/start", chat=STRANGER)
        await h.send(MINT, chat=STRANGER)
        await h.press("mode:auto", chat=STRANGER)
        assert h.tg.texts() == [], h.tg.texts()
        assert h.trader.buys == []

    _run(scenario)


def test_start_menu_offers_both_modes():
    async def scenario(h: Harness):
        await h.send("/start")
        assert "Two snipers in one bot" in h.last()
        assert "mode:manual" in h.tg.buttons() and "mode:auto" in h.tg.buttons()

    _run(scenario)


def test_manual_paper_buy_sell_and_take_profit():
    async def scenario(h: Harness):
        await h.send(MINT)
        assert h.trader.buys == [(MINT, 0.02, True)]
        position_text = h.last()
        assert "PAPER BUY" in position_text and "Hello Coin" in position_text and "Rugcheck 72/100" in position_text
        buttons = h.tg.buttons()
        assert f"sell:{MINT}:50" in buttons and f"sell:{MINT}:100" in buttons
        assert f"sell:{MINT}:25" not in buttons, "free edition sells 50/100 only"

        await h.press(f"tp:{MINT}")
        await h.send("80")
        assert h.book.positions[MINT].take_profit_pct == 80
        assert "Take profit set at +80%" in h.last()

        await h.press(f"sl:{MINT}")
        await h.send(MINT_2)
        assert (MINT_2, 0.02, True) in h.trader.buys, (
            "a mint pasted at a stop-loss prompt is bought, not rejected as a bad percent"
        )
        await h.press(f"sell:{MINT_2}:100")

        await h.press(f"sell:{MINT}:50")
        assert "Sold 50%" in h.last()
        assert h.book.positions[MINT].remaining_pct == 50

        await h.press(f"sell:{MINT}:100")
        assert MINT not in h.book.positions
        assert "SOLD 100%" in h.last() and "Gobli Free" in h.last()

    _run(scenario)


def test_wallet_address_in_rule_builder_is_not_bought():
    async def scenario(h: Harness):
        await h.press("mode:auto")
        assert h.store.mode == MODE_AUTO
        assert "No rule yet" in h.last()
        await h.press("new:creator")
        await h.send(CREATOR)
        assert h.trader.buys == [], "a creator address typed into the builder must never be bought"
        assert "How much SOL per buy" in h.last()
        await h.send("0.5")
        assert "between 0 and" in h.last(), "the free cap applies to rules too"
        await h.send("0.05")
        await h.send("100/40")
        assert any(f"exp:{label}" in h.tg.buttons() for label in config.FREE_RULE_EXPIRY_CHOICES)
        await h.press("exp:6h")
        assert "Ready to arm" in h.last()
        await h.press("arm:yes")

        rule = h.store.rule
        assert rule is not None and rule.active
        assert rule.target == CREATOR and rule.buy_amount_sol == 0.05
        assert rule.take_profit_pct == 100 and rule.stop_loss_pct == 40
        assert h.feed.running, "arming in auto mode starts the launch feed"

        await h.send(MINT)
        assert "You're in <b>Auto</b> mode" in h.last() and h.trader.buys == []

        await h.press("mode:manual")
        assert h.store.mode == MODE_MANUAL
        assert not h.feed.running, "leaving auto mode stops the feed"
        assert "saved, but not watching" in h.last()

    _run(scenario)


def test_ticker_builder_rejects_homoglyphs_and_needs_threshold():
    async def scenario(h: Harness):
        await h.press("new:ticker")
        await h.send("HЕLLO")  # Cyrillic Е
        assert "mixes alphabets" in h.last()
        await h.send("$hello")
        assert "Minimum SOL" in h.last()
        await h.send("500")
        assert "between 0 and" in h.last()
        await h.send("8")
        await h.send("skip")
        await h.send("skip")
        await h.press("exp:1h")
        await h.press("arm:yes")
        rule = h.store.rule
        assert rule.target == "HELLO" and rule.min_sol_in_curve == 8
        assert rule.take_profit_pct is None and rule.buy_amount_sol is None
        await h.press("rule:pause")
        assert not h.store.rule.enabled and not h.feed.running
        await h.press("rule:delete")
        assert h.store.rule is None

    _run(scenario)


def test_free_limits_and_setbuy():
    async def scenario(h: Harness):
        await h.send("/setbuy 0.5")
        assert "caps a buy" in h.last()
        await h.send("/setbuy 0.05")
        assert h.settings.runtime.buy_amount_sol == 0.05
        assert Store(h.settings.state_path).buy_amount_sol == 0.05

        for i in range(config.FREE_MAX_OPEN_POSITIONS):
            await h.send(str(Pubkey(bytes([40 + i] * 32))))
        assert len(h.book.positions) == config.FREE_MAX_OPEN_POSITIONS
        await h.send(MINT_2)
        assert "positions are open" in h.last()
        assert len(h.trader.buys) == config.FREE_MAX_OPEN_POSITIONS

    _run(scenario)


def test_live_needs_a_wallet():
    async def scenario(h: Harness):
        await h.send("/live confirm")
        assert "paper mode is all there is" in h.last()
        assert h.settings.runtime.dry_run

    _run(scenario)


def test_panic_sells_everything_and_blocks_buys():
    async def scenario(h: Harness):
        await h.send(MINT)
        await h.send(MINT_2)
        assert len(h.book.positions) == 2
        await h.send("/panic")
        assert not h.book.positions
        assert "2 position(s) sold" in h.last()
        assert h.store.killed
        await h.send(str(Pubkey(bytes([60] * 32))))
        assert "kill switch" in h.last()
        await h.send("/resume")
        assert not h.store.killed

    _run(scenario)


def test_help_upgrade_config_positions_render():
    async def scenario(h: Harness):
        for command in ("/help", "/upgrade", "/config", "/positions", "/balance", "/rule", "/cancel"):
            h.tg.clear()
            await h.send(command)
            assert h.tg.texts(), f"{command} sent nothing"
        await h.send("/upgrade")
        assert config.UPGRADE_URL in h.tg.buttons()

    _run(scenario)


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        try:
            fn()
            print(f"  PASS  {name}")
        except AssertionError as exc:
            failures += 1
            print(f"  FAIL  {name}\n        {exc}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            print(f"  ERROR {name}\n        {type(exc).__name__}: {exc}")
    print()
    print("FAILED" if failures else "All Telegram flow tests passed")
    sys.exit(1 if failures else 0)
