"""
Launch decoding, rule matching, risk checks, configuration and saved state.

These cover the decisions that spend money: which launches match a rule,
which rules can be armed at all, which buys are refused, and which free
edition limits are enforced.

Run with `pytest tests/` or directly with `python tests/test_core.py`.
"""

from __future__ import annotations

import base64
import os
import struct
import sys
import tempfile
import time
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))

from solders.keypair import Keypair  # noqa: E402
from solders.pubkey import Pubkey  # noqa: E402

import config  # noqa: E402
import pumpfun  # noqa: E402
import rules  # noqa: E402
from risk import RiskGate  # noqa: E402
from state import MODE_AUTO, Store  # noqa: E402

MINT = Pubkey(bytes([11] * 32))
CURVE = Pubkey(bytes([12] * 32))
CREATOR = Pubkey(bytes([13] * 32))
SIGNER = Pubkey(bytes([14] * 32))
USDC = Pubkey.from_string("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v")


# ----------------------------------------------------------------- helpers
def _borsh_string(text: str) -> bytes:
    raw = text.encode("utf-8")
    return struct.pack("<I", len(raw)) + raw


def _create_event(symbol: str = "HELLO", quote_mint: Pubkey | None = None, mayhem: bool = False,
                  user: Pubkey = CREATOR, truncated: bool = False) -> bytes:
    blob = (
        config.CREATE_EVENT_DISCRIMINATOR
        + _borsh_string("Hello Coin")
        + _borsh_string(symbol)
        + _borsh_string("https://ipfs.example/meta.json")
        + bytes(MINT) + bytes(CURVE) + bytes(user) + bytes(CREATOR)
        + struct.pack("<Q", 1_760_000_000)
        + struct.pack("<Q", 1_073_000_000_000_000)
        + struct.pack("<Q", 30_000_000_000)
    )
    if truncated:
        # An older event that stops before the fields added by later upgrades.
        return blob
    blob += struct.pack("<Q", 793_100_000_000_000) + struct.pack("<Q", 1_000_000_000_000_000)
    blob += bytes(Pubkey.from_string(config.TOKEN_2022_PROGRAM_ID))
    blob += bytes([1 if mayhem else 0, 0])
    blob += bytes(quote_mint or Pubkey.default())
    return blob


def _envelope(blob: bytes, err=None, signature: str = "5igSig") -> dict:
    return {
        "jsonrpc": "2.0",
        "method": "logsNotification",
        "params": {
            "result": {
                "context": {"slot": 456_196_392},
                "value": {
                    "signature": signature,
                    "err": err,
                    "logs": [
                        "Program 6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P invoke [1]",
                        "Program log: Instruction: CreateV2",
                        "Program data: " + base64.b64encode(blob).decode(),
                    ],
                },
            },
            "subscription": 1,
        },
    }


def _launch(**kwargs) -> pumpfun.Launch:
    launch = pumpfun.parse_logs_notification(_envelope(_create_event(**kwargs)), received_at=time.monotonic())
    assert launch is not None
    return launch


def _rule(kind=rules.KIND_CREATOR, target=str(CREATOR), **kwargs) -> rules.Rule:
    kwargs.setdefault("expires_at", time.time() + 3600)
    if kind == rules.KIND_TICKER:
        kwargs.setdefault("min_sol_in_curve", 5.0)
    return rules.Rule(kind=kind, target=target, **kwargs)


class _Settings:
    max_sol_per_day = 0.5
    hot_wallet_max_balance_sol = 1.0


def _store() -> Store:
    return Store(Path(tempfile.mkdtemp()) / "state.json")


# ------------------------------------------------------------- decoding
def test_create_event_decodes_every_field():
    launch = _launch(user=SIGNER)
    assert launch.mint == str(MINT)
    assert launch.bonding_curve == str(CURVE)
    assert launch.creator == str(CREATOR)
    assert launch.user == str(SIGNER)
    assert launch.symbol == "HELLO" and launch.name == "Hello Coin"
    assert launch.slot == 456_196_392
    assert launch.is_sol_paired, "an all-zero quote mint means native SOL"


def test_older_event_without_trailing_fields_still_decodes():
    launch = pumpfun.parse_logs_notification(_envelope(_create_event(truncated=True)), received_at=0.0)
    assert launch is not None and launch.is_sol_paired and not launch.is_mayhem_mode


def test_non_sol_quote_and_mayhem_are_read():
    launch = _launch(quote_mint=USDC, mayhem=True)
    assert not launch.is_sol_paired
    assert launch.quote_mint == str(USDC)
    assert launch.is_mayhem_mode


def test_failed_transaction_is_ignored():
    assert pumpfun.parse_logs_notification(_envelope(_create_event(), err={"InstructionError": [0, "x"]}), 0.0) is None


def test_other_events_are_ignored():
    other = bytes([189, 219, 127, 211, 78, 230, 97, 238]) + b"\x00" * 120  # TradeEvent
    assert pumpfun.parse_logs_notification(_envelope(other), 0.0) is None
    assert pumpfun.parse_logs_notification({"result": 123, "id": 1}, 0.0) is None


def test_bonding_curve_decodes_sol_in_curve():
    data = bytes(8) + struct.pack("<QQQQQ", 1_021_664_636_211_565, 31_507_403_573, 741_000_000_000_000,
                                  1_507_403_573, 1_000_000_000_000_000) + b"\x00" + bytes(CREATOR)
    curve = pumpfun.decode_bonding_curve(data)
    assert abs(curve.sol_in_curve - 1.507403573) < 1e-9
    assert curve.complete is False


def test_ticker_normalization_and_homoglyphs():
    assert pumpfun.normalize_ticker(" $hello ") == "HELLO"
    assert pumpfun.normalize_ticker("ＨＥＬＬＯ") == "HELLO"
    assert pumpfun.is_mixed_script("HЕLLO")  # Cyrillic Е
    assert not pumpfun.is_mixed_script("HELLO2")


# ---------------------------------------------------------------- rules
def test_creator_rule_matches_creator_or_signer():
    assert rules.match(_rule(), _launch()) == "creator wallet"
    signer_rule = _rule(target=str(SIGNER))
    assert rules.match(signer_rule, _launch(user=SIGNER)) == "creator wallet"
    assert rules.match(_rule(target=str(USDC)), _launch()) is None


def test_creator_rule_buys_non_sol_pairs_ticker_rule_does_not():
    usdc_launch = _launch(quote_mint=USDC)
    assert rules.match(_rule(), usdc_launch) == "creator wallet"
    assert rules.match(_rule(kind=rules.KIND_TICKER, target="HELLO"), usdc_launch) is None


def test_ticker_rule_is_exact_and_case_insensitive():
    rule = _rule(kind=rules.KIND_TICKER, target="hello")
    assert rules.match(rule, _launch(symbol="$HELLO")) == "ticker"
    assert rules.match(rule, _launch(symbol="HELLOCOIN")) is None, "contains-matching is a paid feature"
    assert rules.match(rule, _launch(symbol="HЕLLO")) is None, "a homoglyph copy must not match"


def test_inactive_rules_never_match():
    launch = _launch()
    assert rules.match(None, launch) is None
    assert rules.match(_rule(enabled=False), launch) is None
    assert rules.match(_rule(expires_at=time.time() - 1), launch) is None
    assert rules.match(_rule(buys_done=config.FREE_MAX_RULE_BUYS), launch) is None


def test_rule_validation():
    assert rules.validate_rule(_rule()) == []
    assert rules.validate_rule(_rule(kind=rules.KIND_TICKER, target="HELLO")) == []
    no_threshold = _rule(kind=rules.KIND_TICKER, target="HELLO", min_sol_in_curve=None)
    assert any("minimum" in p for p in rules.validate_rule(no_threshold))
    assert rules.validate_rule(_rule(kind=rules.KIND_TICKER, target="HЕLLO"))
    assert rules.validate_rule(_rule(buy_amount_sol=0))
    assert rules.validate_rule(_rule(buy_amount_sol=5.0)) == []
    assert rules.validate_rule(_rule(expires_at=time.time() - 5))
    assert rules.validate_rule(_rule(stop_loss_pct=150))


def test_rule_round_trips_through_state_file():
    store = _store()
    rule = _rule(take_profit_pct=100, stop_loss_pct=40, buy_amount_sol=0.05)
    store.set_rule(rule)
    store.set_mode(MODE_AUTO)
    reloaded = Store(store._path)  # noqa: SLF001
    assert reloaded.mode == MODE_AUTO
    assert reloaded.rule == rule
    reloaded.record_auto_buy(str(MINT))
    assert Store(store._path).rule.exhausted  # noqa: SLF001


# ----------------------------------------------------------------- risk
def _check(store, **overrides):
    args = dict(mint=str(MINT), amount_sol=0.05, open_positions=0, holding_mint=False,
                wallet_balance_sol=0.5, paper=False, auto=False)
    args.update(overrides)
    return RiskGate(_Settings(), store).check(**args)


def test_risk_allows_a_normal_buy():
    assert _check(_store()) is None


def test_risk_enforces_free_limits():
    store = _store()
    assert "positions" in _check(store, open_positions=config.FREE_MAX_OPEN_POSITIONS)
    assert "already hold" in _check(store, holding_mint=True)


def test_risk_kill_switch_blocks_paper_too():
    store = _store()
    store.set_killed(True)
    assert "kill switch" in _check(store, paper=True)


def test_risk_daily_cap_and_balance_apply_to_live_only():
    store = _store()
    store.record_live_spend(0.48)
    assert "daily cap" in _check(store)
    assert _check(store, paper=True) is None
    fresh = _store()
    assert "wallet holds" in _check(fresh, wallet_balance_sol=0.02)
    assert _check(fresh, wallet_balance_sol=0.02, paper=True) is None


def test_auto_never_buys_the_same_mint_twice():
    store = _store()
    store.bought_mints.append(str(MINT))
    assert "already bought" in _check(store, auto=True)
    assert _check(store, auto=False) is None


def test_startup_balance_ceiling():
    gate = RiskGate(_Settings(), _store())
    assert gate.startup_balance_check(0.5) is None
    assert "HOT_WALLET_MAX_BALANCE_SOL" in gate.startup_balance_check(5.0)


# --------------------------------------------------------------- config
_ENV_KEYS = ("HELIUS_API_KEY", "PRIVATE_KEY", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID", "BUY_AMOUNT_SOL",
             "DRY_RUN", "JUPITER_API_KEY", "HTTP_RPC_URL", "WS_RPC_URL")


def _load(**env):
    saved = {k: os.environ.get(k) for k in _ENV_KEYS}
    try:
        for key in _ENV_KEYS:
            os.environ.pop(key, None)
        os.environ.update({"HELIUS_API_KEY": "1a2b3c4d-5e6f-7a8b-9c0d-1e2f3a4b5c6d",
                           "TELEGRAM_BOT_TOKEN": "123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
                           "TELEGRAM_CHAT_ID": "12345"})
        os.environ.update(env)
        return config.load_settings()
    finally:
        for key, value in saved.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def test_no_private_key_means_paper_only():
    settings = _load(DRY_RUN="false")
    assert not settings.has_wallet
    assert settings.runtime.dry_run, "without a wallet, paper mode is forced on"
    assert settings.http_rpc_url.startswith("https://mainnet.helius-rpc.com/?api-key=")
    assert settings.ws_rpc_url.startswith("wss://")


def test_private_key_and_live_mode():
    settings = _load(PRIVATE_KEY=str(Keypair()), DRY_RUN="false")
    assert settings.has_wallet and not settings.runtime.dry_run


def test_paper_is_the_default():
    assert _load(PRIVATE_KEY=str(Keypair())).runtime.dry_run


def test_buy_amount_has_no_free_cap():
    assert _load(BUY_AMOUNT_SOL="5").runtime.buy_amount_sol == 5.0


def test_jupiter_host_follows_api_key():
    assert _load().jupiter_base_url == config.JUPITER_KEYLESS_BASE
    keyed = _load(JUPITER_API_KEY="abc123")
    assert keyed.jupiter_base_url == config.JUPITER_KEYED_BASE and keyed.jupiter_api_key == "abc123"


def test_every_problem_is_reported_at_once():
    try:
        _load(HELIUS_API_KEY="", TELEGRAM_CHAT_ID="not-a-number", PRIVATE_KEY="garbage")
    except config.ConfigError as exc:
        message = str(exc)
        assert "HELIUS_API_KEY" in message and "TELEGRAM_CHAT_ID" in message and "PRIVATE_KEY" in message
    else:
        raise AssertionError("a broken .env must not load")


def test_runtime_overrides_survive_restart_within_caps():
    store = _store()
    runtime = config.RuntimeConfig(buy_amount_sol=0.02, slippage_bps=500, auto_slippage_bps=2500,
                                   priority_fee_lamports=300000, dry_run=True)
    runtime.buy_amount_sol = 0.07
    store.remember_runtime(runtime)
    fresh = config.RuntimeConfig(buy_amount_sol=0.02, slippage_bps=500, auto_slippage_bps=2500,
                                 priority_fee_lamports=300000, dry_run=False)
    Store(store._path).apply_runtime_overrides(fresh)  # noqa: SLF001
    assert fresh.buy_amount_sol == 0.07
    assert fresh.dry_run is False, "paper/live is never restored from state"


# --------------------------------------------------------- trader / feed
def test_fresh_coin_quote_is_retried_until_routable():
    import asyncio

    from trader import Trader

    class _Jupiter:
        def __init__(self, errors):
            self.errors = list(errors)
            self.calls = 0

        async def quote(self, *args):
            self.calls += 1
            if self.errors:
                return None, self.errors.pop(0)
            return {"outAmount": "123", "routePlan": [{}]}, None

    saved_interval = config.ROUTE_RETRY_INTERVAL_SECONDS
    config.ROUTE_RETRY_INTERVAL_SECONDS = 0.0
    try:
        for not_ready in ("The token X is not tradable", "Could not find any route / COULD_NOT_FIND_ANY_ROUTE"):
            jupiter = _Jupiter([not_ready, not_ready])
            trader = Trader(None, None, jupiter, type("S", (), {"keypair": None})())
            quote, error = asyncio.run(trader._quote("a", "b", 1, 100, wait_seconds=5))  # noqa: SLF001
            assert quote is not None and jupiter.calls == 3, (not_ready, jupiter.calls, error)

        jupiter = _Jupiter(["Invalid mint address"])
        trader = Trader(None, None, jupiter, type("S", (), {"keypair": None})())
        quote, error = asyncio.run(trader._quote("a", "b", 1, 100, wait_seconds=5))  # noqa: SLF001
        assert quote is None and jupiter.calls == 1, "a real error must not be retried"
    finally:
        config.ROUTE_RETRY_INTERVAL_SECONDS = saved_interval


def test_refused_feed_is_not_restarted_immediately():
    import asyncio

    from feed import LaunchFeed

    async def scenario():
        feed = LaunchFeed("wss://rpc.invalid")
        feed._refused_at = time.monotonic()  # noqa: SLF001
        feed.unavailable_reason = "method not available on your plan"
        feed.start()
        assert not feed.running
        feed._refused_at -= 1_000  # noqa: SLF001
        feed.start()
        assert feed.running and feed.unavailable_reason is None
        await feed.stop()

    asyncio.run(scenario())


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        try:
            fn()
            print(f"  PASS  {name}")
        except AssertionError as exc:
            failures += 1
            print(f"  FAIL  {name}\n        {exc}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            print(f"  ERROR {name}\n        {type(exc).__name__}: {exc}")
    print()
    print("FAILED" if failures else "All core tests passed")
    sys.exit(1 if failures else 0)
