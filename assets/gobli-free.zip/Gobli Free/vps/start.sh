#!/usr/bin/env bash
#
# Run the bot in the foreground. For unattended running use the systemd
# service instead - see vps/gobli-free.service.
#
#   bash vps/start.sh

set -euo pipefail

cd "$(dirname "$0")/.."

if [ ! -d venv ]; then
    echo "No virtual environment found. Run: bash vps/install.sh"
    exit 1
fi

if [ ! -f .env ]; then
    echo "No .env found. Copy .env.example to .env and fill it in, or use setup.html."
    exit 1
fi

# Re-applied on every start: a re-copied or restored .env can silently
# regress to a world-readable mode otherwise.
chmod 600 .env

exec ./venv/bin/python main.py
