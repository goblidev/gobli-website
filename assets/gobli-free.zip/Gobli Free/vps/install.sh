#!/usr/bin/env bash
#
# One-time setup on a fresh Ubuntu/Debian VPS.
#
#   bash vps/install.sh
#
# Creates the virtual environment, installs the pinned dependencies, locks
# down .env and runs the tests. It does not start anything - fill in .env
# first, then run vps/start.sh or install the systemd service.

set -euo pipefail

cd "$(dirname "$0")/.."
PROJECT_DIR="$(pwd)"

echo "Installing into: ${PROJECT_DIR}"
echo

if ! command -v python3 >/dev/null 2>&1; then
    echo "python3 is not installed. On Ubuntu/Debian:"
    echo "  sudo apt update && sudo apt install -y python3 python3-venv python3-pip"
    exit 1
fi

# The pinned wheels have no builds for the very newest Python releases.
PY_VERSION="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
echo "Python ${PY_VERSION} detected"
case "${PY_VERSION}" in
    3.10|3.11|3.12|3.13) ;;
    *)
        echo
        echo "WARNING: this is tested on Python 3.10 - 3.13."
        echo "Installation may fail on ${PY_VERSION}. Install python3.12 and re-run if so."
        echo
        ;;
esac

if [ ! -d venv ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

echo "Installing dependencies..."
./venv/bin/python -m pip install --upgrade pip --quiet
./venv/bin/python -m pip install -r requirements.txt

if [ ! -f .env ]; then
    cp .env.example .env
    echo
    echo "Created .env from the example. Fill it in before starting."
fi

# .env can hold a private key. Anything looser than 600 on a shared box is a
# real exposure, and the bot refuses to start if it finds one.
chmod 600 .env
echo "Locked .env to owner-only (chmod 600)"

echo
echo "Verifying the install..."
./venv/bin/python tests/test_core.py
./venv/bin/python tests/test_network.py

echo
echo "Done."
echo
echo "Next:"
echo "  1. nano .env                  fill in every value (or upload the one setup.html wrote)"
echo "  2. bash vps/start.sh          run it in the foreground to check it works"
echo "  3. Ctrl+C, then install the service for unattended running:"
echo "       sudo cp vps/gobli-free.service /etc/systemd/system/"
echo "       sudo nano /etc/systemd/system/gobli-free.service   # fix User= and the paths"
echo "       sudo systemctl daemon-reload"
echo "       sudo systemctl enable --now gobli-free"
echo "       journalctl -u gobli-free -f"
