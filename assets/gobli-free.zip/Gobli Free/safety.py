"""
Token safety checks for the manual mode.

Runs a DexScreener lookup (name, symbol, price, market cap, liquidity) and a
Rugcheck score concurrently, inside a fixed time budget, while the buy is
already in flight. The results are informational: they appear on the BOUGHT
message as context and warnings, and never block or delay a purchase.

Gobli Pro adds GoPlus (Token-2022 transfer fees and
non-transferable flags) and a top-holder concentration check.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Optional

import aiohttp

import config
from logger import get_logger

_log = get_logger(__name__)


@dataclass
class SafetyReport:
    name: Optional[str] = None
    symbol: Optional[str] = None
    price_usd: Optional[float] = None
    liquidity_usd: Optional[float] = None
    market_cap_usd: Optional[float] = None
    # 0-100, higher = safer (Rugcheck's own score is inverted, see below).
    rugcheck_score: Optional[float] = None
    timed_out: bool = False

    def warnings(self) -> list[str]:
        flags: list[str] = []
        if self.liquidity_usd is not None and self.liquidity_usd < config.WARN_MIN_LIQUIDITY_USD:
            flags.append(f"low liquidity (${self.liquidity_usd:,.0f})")
        if self.rugcheck_score is not None and self.rugcheck_score < config.WARN_MIN_RUGCHECK_SCORE:
            flags.append(f"low Rugcheck score ({self.rugcheck_score:.0f}/100)")
        return flags


class SafetyChecker:
    def __init__(self, http: aiohttp.ClientSession) -> None:
        self._http = http
        self._timeout = aiohttp.ClientTimeout(total=config.HTTP_REQUEST_TIMEOUT_SECONDS)

    async def check(self, mint: str) -> SafetyReport:
        try:
            return await asyncio.wait_for(self._check(mint), timeout=config.SAFETY_CHECK_BUDGET_SECONDS)
        except asyncio.TimeoutError:
            return SafetyReport(timed_out=True)

    async def _check(self, mint: str) -> SafetyReport:
        dex, rug = await asyncio.gather(self._dexscreener(mint), self._rugcheck(mint), return_exceptions=True)
        dex = dex if isinstance(dex, dict) else {}
        rug_score = rug if isinstance(rug, float) else None
        return SafetyReport(
            name=dex.get("name"),
            symbol=dex.get("symbol"),
            price_usd=dex.get("price_usd"),
            liquidity_usd=dex.get("liquidity_usd"),
            market_cap_usd=dex.get("market_cap_usd"),
            rugcheck_score=rug_score,
        )

    async def _dexscreener(self, mint: str) -> dict:
        try:
            async with self._http.get(f"{config.DEXSCREENER_TOKENS_URL}/{mint}", timeout=self._timeout) as resp:
                if resp.status != 200:
                    return {}
                data = await resp.json(content_type=None)
        except Exception:  # noqa: BLE001
            return {}
        pairs = data.get("pairs") or []
        if not pairs:
            return {}
        # A mint can have several pools - the deepest is the most representative.
        best = max(pairs, key=lambda p: (p.get("liquidity") or {}).get("usd") or 0)
        base = best.get("baseToken") or {}

        def _num(value) -> Optional[float]:
            try:
                return float(value) if value is not None else None
            except (TypeError, ValueError):
                return None

        return {
            "name": base.get("name"),
            "symbol": base.get("symbol"),
            "price_usd": _num(best.get("priceUsd")),
            "liquidity_usd": _num((best.get("liquidity") or {}).get("usd")),
            "market_cap_usd": _num(best.get("marketCap") or best.get("fdv")),
        }

    async def _rugcheck(self, mint: str) -> Optional[float]:
        try:
            async with self._http.get(
                f"{config.RUGCHECK_API_BASE}/tokens/{mint}/report/summary", timeout=self._timeout
            ) as resp:
                if resp.status != 200:
                    return None
                data = await resp.json(content_type=None)
        except Exception:  # noqa: BLE001
            return None
        # Rugcheck's score_normalised is 0-100 where HIGHER = RISKIER. It is
        # inverted here into a safety score, so a higher number reads as safer.
        risk = data.get("score_normalised", data.get("score"))
        try:
            return max(0.0, 100.0 - float(risk)) if risk is not None else None
        except (TypeError, ValueError):
            return None
